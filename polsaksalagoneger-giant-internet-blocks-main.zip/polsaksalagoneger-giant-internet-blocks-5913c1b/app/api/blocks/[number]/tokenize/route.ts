import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { isDatabaseAvailable } from "@/lib/db";
import { issueBlockToken } from "@/lib/models";

const tokenizeBlockSchema = z.object({});

export const dynamic = "force-dynamic";

// Выпуск блока в сеть Ethereum: блок получает уникальный токен-сертификат
// и статус выпуска в сеть.
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ number: string }> }
) {
  const { number } = await params;
  const parsedNumber = Number(number);

  if (!Number.isSafeInteger(parsedNumber) || parsedNumber <= 0) {
    return NextResponse.json(
      { error: "Некорректный номер блока" },
      { status: 400 }
    );
  }

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  try {
    let body: unknown = {};
    try {
      body = await request.json();
    } catch {
      void 0;
    }

    const parsed = tokenizeBlockSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Некорректные данные", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const block = await issueBlockToken(parsedNumber);
    return NextResponse.json({ block });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "BLOCK_NOT_FOUND") {
      return NextResponse.json({ error: "Блок не найден" }, { status: 404 });
    }
    if (message === "BLOCK_NOT_READY") {
      return NextResponse.json(
        { error: "Блок ещё не готов к выпуску в сеть" },
        { status: 409 }
      );
    }
    if (message === "ALREADY_TOKENIZED") {
      return NextResponse.json(
        { error: "Блок уже выпущен в сеть Ethereum" },
        { status: 409 }
      );
    }
    console.error("Ошибка выпуска блока в сеть Ethereum:", error);
    return NextResponse.json(
      { error: "Ошибка выпуска блока в сеть Ethereum" },
      { status: 500 }
    );
  }
}
