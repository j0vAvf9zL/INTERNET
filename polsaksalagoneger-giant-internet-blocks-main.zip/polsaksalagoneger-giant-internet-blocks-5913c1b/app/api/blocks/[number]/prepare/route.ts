import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { isDatabaseAvailable } from "@/lib/db";
import { prepareBlockForMining } from "@/lib/models";

const prepareBlockSchema = z.object({});

export const dynamic = "force-dynamic";

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ number: string }> }
) {
  const { number } = await params;
  const parsedNumber = Number(number);

  if (!Number.isSafeInteger(parsedNumber) || parsedNumber <= 0) {
    return NextResponse.json(
      { error: "Некорректный номер блока" },
      { status: 400 }
    );
  }

  if (!(await isDatabaseAvailable())) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  try {
    let body: unknown = {};
    try {
      body = await request.json();
    } catch {
      void 0;
    }

    const parsed = prepareBlockSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Некорректные данные", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const block = await prepareBlockForMining(parsedNumber);
    return NextResponse.json({ block });
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    if (message === "BLOCK_NOT_FOUND") {
      return NextResponse.json({ error: "Блок не найден" }, { status: 404 });
    }
    if (message === "BLOCK_NOT_READY") {
      return NextResponse.json(
        { error: "Блок ещё не готов к подготовке" },
        { status: 409 }
      );
    }
    if (message === "ALREADY_PREPARED") {
      return NextResponse.json(
        { error: "Блок уже подготовлен к майнингу" },
        { status: 409 }
      );
    }
    if (message === "ALREADY_PREPARING") {
      return NextResponse.json(
        { error: "Подготовка блока уже идёт" },
        { status: 409 }
      );
    }
    if (message === "ALREADY_MINED") {
      return NextResponse.json(
        { error: "Блок уже обработан майнером" },
        { status: 409 }
      );
    }
    console.error("Ошибка подготовки блока:", error);
    return NextResponse.json(
      { error: "Ошибка подготовки блока" },
      { status: 500 }
    );
  }
}
