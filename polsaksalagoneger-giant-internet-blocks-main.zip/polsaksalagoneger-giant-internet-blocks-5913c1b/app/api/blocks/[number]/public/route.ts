import { NextRequest } from "next/server";
import { isDatabaseAvailable } from "@/lib/db";
import { getBlockByNumber } from "@/lib/models";
import { createBlockDataStream } from "@/lib/block-file";

export const dynamic = "force-dynamic";

// Постоянная публичная ссылка на файл блока. Позволяет любому человеку скачать
// выпущенный блок по прямой ссылке; работает для всех выпущенных блоков.
export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ number: string }> }
) {
  const { number } = await params;
  const parsedNumber = Number(number);

  if (!Number.isSafeInteger(parsedNumber) || parsedNumber <= 0) {
    return new Response("Некорректный номер блока", { status: 400 });
  }

  if (!(await isDatabaseAvailable())) {
    return new Response("База данных недоступна", { status: 503 });
  }

  const block = await getBlockByNumber(parsedNumber);
  if (!block) {
    return new Response("Блок не найден", { status: 404 });
  }

  if (block.status !== "ready") {
    return new Response("Блок ещё генерируется", { status: 425 });
  }

  const stream = await createBlockDataStream(
    block.number,
    block.sizeBytes,
    block.content
  );

  return new Response(stream as unknown as BodyInit, {
    headers: {
      "Content-Type": "application/octet-stream",
      "Content-Length": String(block.sizeBytes),
      "Content-Disposition": `attachment; filename="${block.fileName}"`,
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
