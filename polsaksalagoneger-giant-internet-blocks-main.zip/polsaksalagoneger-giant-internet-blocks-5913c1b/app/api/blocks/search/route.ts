import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { isDatabaseAvailable } from "@/lib/db";
import { searchBlocks } from "@/lib/models";
import { mockBlocks } from "@/lib/mock-data";
import { matchesBlockQuery } from "@/lib/block-search";

const searchSchema = z.object({
  q: z.string().trim().max(200).optional(),
  type: z.enum(["all", "site", "news", "file"]).optional(),
  source: z.enum(["all", "manual", "factory"]).optional(),
  date: z
    .string()
    .regex(/^\d{4}-\d{2}-\d{2}$/, "Дата должна быть в формате YYYY-MM-DD")
    .optional(),
});

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const url = new URL(request.url);
  const parsed = searchSchema.safeParse({
    q: url.searchParams.get("q") ?? undefined,
    type: url.searchParams.get("type") ?? undefined,
    source: url.searchParams.get("source") ?? undefined,
    date: url.searchParams.get("date") ?? undefined,
  });

  if (!parsed.success) {
    return NextResponse.json(
      {
        error: "Некорректные параметры поиска",
        details: parsed.error.flatten(),
      },
      { status: 400 }
    );
  }

  const query = parsed.data;

  if (!(await isDatabaseAvailable())) {
    const blocks = mockBlocks
      .filter((block) => matchesBlockQuery(block, query))
      .sort((a, b) => b.number - a.number);
    return NextResponse.json({ blocks, query });
  }

  try {
    const blocks = await searchBlocks(query);
    return NextResponse.json({ blocks, query });
  } catch (error) {
    console.error("Ошибка поиска блоков:", error);
    return NextResponse.json(
      { error: "Ошибка поиска блоков" },
      { status: 500 }
    );
  }
}
