import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { isDatabaseAvailable } from "@/lib/db";
import { createBlock, getBlocksOverview } from "@/lib/models";
import { mockBlocks, mockBlockStats } from "@/lib/mock-data";

const releaseBlockSchema = z.object({});

export const dynamic = "force-dynamic";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (dbAvailable) {
    try {
      const overview = await getBlocksOverview();
      return NextResponse.json(overview);
    } catch (error) {
      console.error("Ошибка получения блоков:", error);
      return NextResponse.json(
        { error: "Ошибка получения данных из DynamoDB" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({ stats: mockBlockStats, blocks: mockBlocks });
}

export async function POST(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  try {
    let body: unknown = {};
    try {
      body = await request.json();
    } catch {
      // пустое тело — допустимо для выпуска блока
    }

    const parsed = releaseBlockSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Некорректные данные", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const block = await createBlock();
    return NextResponse.json(block, { status: 201 });
  } catch (error) {
    console.error("Ошибка создания блока:", error);
    return NextResponse.json(
      { error: "Ошибка создания блока" },
      { status: 500 }
    );
  }
}
