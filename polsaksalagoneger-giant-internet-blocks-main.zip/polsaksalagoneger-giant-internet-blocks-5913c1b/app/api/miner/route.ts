import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { isDatabaseAvailable } from "@/lib/db";
import { ensureMinerEngineStarted } from "@/lib/miner-engine";
import {
  getMinerLogs,
  getMinerState,
  getMiningResults,
  listPreparedUnminedBlocks,
  startMiner,
  stopMiner,
} from "@/lib/models";
import {
  mockMinerLogs,
  mockMinerState,
  mockMiningResults,
} from "@/lib/mock-data";

const minerActionSchema = z.object({
  action: z.enum(["start", "stop"]),
});

export const dynamic = "force-dynamic";

export async function GET() {
  const dbAvailable = await isDatabaseAvailable();

  if (dbAvailable) {
    try {
      await ensureMinerEngineStarted();
      const [miner, results, logs, queue] = await Promise.all([
        getMinerState(),
        getMiningResults(),
        getMinerLogs(),
        listPreparedUnminedBlocks(),
      ]);
      return NextResponse.json({
        miner,
        results,
        logs,
        queueCount: queue.length,
        dbAvailable: true,
      });
    } catch (error) {
      console.error("Ошибка получения состояния майнера:", error);
      return NextResponse.json(
        { error: "Ошибка получения состояния майнера" },
        { status: 500 }
      );
    }
  }

  return NextResponse.json({
    miner: mockMinerState,
    results: mockMiningResults,
    logs: mockMinerLogs,
    queueCount: 1,
    dbAvailable: false,
  });
}

export async function POST(request: NextRequest) {
  const dbAvailable = await isDatabaseAvailable();

  if (!dbAvailable) {
    return NextResponse.json(
      { error: "База данных недоступна в статическом режиме" },
      { status: 503 }
    );
  }

  try {
    let body: unknown = {};
    try {
      body = await request.json();
    } catch {
      void 0;
    }

    const parsed = minerActionSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Некорректные данные", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    if (parsed.data.action === "start") {
      const miner = await startMiner();
      await ensureMinerEngineStarted();
      return NextResponse.json({ miner, dbAvailable: true });
    }

    const miner = await stopMiner();
    return NextResponse.json({ miner, dbAvailable: true });
  } catch (error) {
    console.error("Ошибка управления майнером:", error);
    return NextResponse.json(
      { error: "Ошибка управления майнером" },
      { status: 500 }
    );
  }
}
