"use client";

import { useEffect, useRef, useState } from "react";
import {
  ChevronDown,
  Crosshair,
  Download,
  Factory,
  FileText,
  Gem,
  Globe,
  Loader2,
  Newspaper,
  PackageCheck,
  Pickaxe,
  Search,
  SearchX,
  X,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { BlockRecord } from "@/lib/models";
import type { ArchiveContentItem } from "@/lib/archive";
import {
  findMatchedItems,
  type BlockSearchQuery,
  type ContentTypeFilter,
  type SourceFilter,
} from "@/lib/block-search";

interface BlockSearchProps {
  dbAvailable: boolean;
  onOpenBlock: (block: BlockRecord) => void;
}

const CONTENT_TYPE_OPTIONS: { value: ContentTypeFilter; label: string }[] = [
  { value: "all", label: "Любой тип контента" },
  { value: "site", label: "Сайты" },
  { value: "news", label: "Новости" },
  { value: "file", label: "Файлы" },
];

const SOURCE_OPTIONS: { value: SourceFilter; label: string }[] = [
  { value: "all", label: "Любой источник" },
  { value: "manual", label: "Ручной" },
  { value: "factory", label: "Фабрика" },
];

function pluralForm(n: number, one: string, few: string, many: string): string {
  const abs = Math.abs(n) % 100;
  const last = abs % 10;
  if (abs > 10 && abs < 20) return many;
  if (last === 1) return one;
  if (last >= 2 && last <= 4) return few;
  return many;
}

function formatUtc(iso: string): string {
  return iso
    .replace("T", " ")
    .replace(/\.\d{3}Z$/, "")
    .concat(" UTC");
}

const KIND_ICON: Record<ArchiveContentItem["kind"], typeof Globe> = {
  site: Globe,
  news: Newspaper,
  file: FileText,
};

const KIND_LABEL: Record<ArchiveContentItem["kind"], string> = {
  site: "сайт",
  news: "новость",
  file: "файл",
};

const inputClass =
  "w-full rounded-sm border border-emerald-900/70 bg-black/40 px-2.5 py-1.5 text-xs text-emerald-300 placeholder:text-emerald-700 transition-colors focus:border-emerald-500/60 focus:outline-none focus:ring-1 focus:ring-emerald-500/40";

export function BlockSearch({ dbAvailable, onOpenBlock }: BlockSearchProps) {
  const [q, setQ] = useState("");
  const [type, setType] = useState<ContentTypeFilter>("all");
  const [source, setSource] = useState<SourceFilter>("all");
  const [date, setDate] = useState("");
  const [results, setResults] = useState<BlockRecord[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const requestIdRef = useRef(0);

  const active =
    q.trim().length > 0 ||
    type !== "all" ||
    source !== "all" ||
    date.length > 0;

  const query: BlockSearchQuery = {
    q: q.trim() || undefined,
    type,
    source,
    date: date || undefined,
  };

  useEffect(() => {
    if (!active) {
      requestIdRef.current++;
      setResults(null);
      setLoading(false);
      setError(null);
      return;
    }

    setLoading(true);
    const timer = setTimeout(async () => {
      const requestId = ++requestIdRef.current;
      const params = new URLSearchParams();
      if (query.q) params.set("q", query.q);
      if (query.type && query.type !== "all") params.set("type", query.type);
      if (query.source && query.source !== "all")
        params.set("source", query.source);
      if (query.date) params.set("date", query.date);

      try {
        const response = await fetch(`/api/blocks/search?${params.toString()}`);
        const data = await response.json().catch(() => null);
        if (requestId !== requestIdRef.current) return;
        if (!response.ok) {
          setError(data?.error ?? "Ошибка поиска");
          setResults([]);
        } else {
          setResults(Array.isArray(data?.blocks) ? data.blocks : []);
          setError(null);
        }
      } catch {
        if (requestId !== requestIdRef.current) return;
        setError("Ошибка соединения с сервером");
        setResults([]);
      } finally {
        if (requestId === requestIdRef.current) setLoading(false);
      }
    }, 300);

    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active, q, type, source, date]);

  const reset = () => {
    setQ("");
    setType("all");
    setSource("all");
    setDate("");
  };

  return (
    <section className="space-y-3">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-emerald-600">
          <Search className="size-4" />
          Поиск блоков
        </div>
        {active && (
          <button
            type="button"
            onClick={reset}
            className="inline-flex items-center gap-1 rounded-sm border border-emerald-800/70 bg-emerald-950/40 px-2 py-0.5 text-[10px] uppercase tracking-[0.2em] text-emerald-600 transition-colors hover:text-emerald-400"
          >
            <X className="size-3" />
            Сбросить
          </button>
        )}
      </div>

      <input
        type="text"
        value={q}
        onChange={(event) => setQ(event.target.value)}
        placeholder="Номер, дата, сайт, новость или файл внутри..."
        className={inputClass}
      />

      <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
        <label className="block space-y-1">
          <span className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            Тип контента
          </span>
          <span className="relative block">
            <select
              value={type}
              onChange={(event) =>
                setType(event.target.value as ContentTypeFilter)
              }
              className={cn(inputClass, "appearance-none pr-7")}
            >
              {CONTENT_TYPE_OPTIONS.map((option) => (
                <option
                  key={option.value}
                  value={option.value}
                  className="bg-[#070c09] text-emerald-300"
                >
                  {option.label}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-2 top-1/2 size-3 -translate-y-1/2 text-emerald-600" />
          </span>
        </label>
        <label className="block space-y-1">
          <span className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            Источник
          </span>
          <span className="relative block">
            <select
              value={source}
              onChange={(event) =>
                setSource(event.target.value as SourceFilter)
              }
              className={cn(inputClass, "appearance-none pr-7")}
            >
              {SOURCE_OPTIONS.map((option) => (
                <option
                  key={option.value}
                  value={option.value}
                  className="bg-[#070c09] text-emerald-300"
                >
                  {option.label}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-2 top-1/2 size-3 -translate-y-1/2 text-emerald-600" />
          </span>
        </label>
      </div>

      <label className="block space-y-1">
        <span className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
          Дата выпуска
        </span>
        <input
          type="date"
          value={date}
          onChange={(event) => setDate(event.target.value)}
          className={cn(
            inputClass,
            "text-emerald-400 [color-scheme:dark]",
            !date && "text-emerald-700"
          )}
        />
      </label>

      {!active ? (
        <p className="rounded-sm border border-emerald-900/50 bg-black/30 px-3 py-2 text-[11px] leading-relaxed text-emerald-700">
          Ищите блоки по номеру, дате выпуска, источнику (ручной/фабрика),
          составу или содержимому: сайтам, новостям и файлам из Интернет-архива.
        </p>
      ) : (
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            {loading ? (
              <Loader2 className="size-3 animate-spin text-amber-400" />
            ) : (
              <ChevronDown className="size-3 text-amber-500" />
            )}
            Результаты
            {results !== null && !loading && (
              <span className="text-amber-500 tabular-nums">
                ({results.length})
              </span>
            )}
          </div>

          {error && (
            <p className="rounded-sm border border-amber-700/60 bg-amber-950/30 px-3 py-2 text-[11px] text-amber-500/90">
              {error}
            </p>
          )}

          {results !== null && !loading && results.length === 0 && !error && (
            <div className="flex flex-col items-center gap-2 rounded-sm border border-emerald-900/50 bg-black/30 px-4 py-6 text-center">
              <div className="flex size-9 items-center justify-center rounded-full bg-emerald-950/60">
                <SearchX className="size-4 text-emerald-700" />
              </div>
              <p className="text-xs text-emerald-600">Ничего не найдено</p>
              <p className="text-[11px] text-emerald-800">
                Измените запрос или фильтры
              </p>
            </div>
          )}

          {results !== null &&
            !loading &&
            results.length > 0 &&
            results.map((block) => (
              <SearchResultCard
                key={block.id}
                block={block}
                query={query}
                dbAvailable={dbAvailable}
                onOpenBlock={onOpenBlock}
              />
            ))}
        </div>
      )}
    </section>
  );
}

function SearchResultCard({
  block,
  query,
  dbAvailable,
  onOpenBlock,
}: {
  block: BlockRecord;
  query: BlockSearchQuery;
  dbAvailable: boolean;
  onOpenBlock: (block: BlockRecord) => void;
}) {
  const matched = findMatchedItems(block, query);
  const content = block.content;
  const hasContent =
    !!content &&
    (content.sites.length > 0 ||
      content.news.length > 0 ||
      content.files.length > 0);

  return (
    <div className="rounded-sm border border-emerald-900/60 bg-black/40 px-3 py-2.5 text-[11px]">
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
        <span className="font-semibold text-amber-400 tabular-nums">
          #{block.number}
        </span>
        <span className="text-emerald-500/80">
          {formatUtc(block.releasedAt)}
        </span>
        {block.source === "factory" ? (
          <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-800/60 bg-emerald-950/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-500">
            <Factory className="size-2.5" />
            Фабрика
          </span>
        ) : (
          <span className="rounded-sm border border-emerald-900/60 bg-black/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-700">
            Ручной
          </span>
        )}
        <span className="text-emerald-400 tabular-nums">{block.sizeGb} ГБ</span>
        {block.status === "generating" ? (
          <span className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-amber-400">
            <Loader2 className="size-2.5 animate-spin" />
            Генерация...
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-400">
            <span className="size-1.5 rounded-full bg-emerald-400" />
            Готов
          </span>
        )}
        {block.miningStatus === "preparing" && (
          <span className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-amber-400">
            <Loader2 className="size-2.5 animate-spin" />
            Подготовка...
          </span>
        )}
        {block.miningStatus === "prepared" && (
          <span className="inline-flex items-center gap-1 rounded-sm border border-cyan-700/60 bg-cyan-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-cyan-400">
            <PackageCheck className="size-2.5" />
            Подготовлен
          </span>
        )}
        {block.miningStatus === "mined" && (
          <span
            className="inline-flex items-center gap-1 rounded-sm border border-violet-700/60 bg-violet-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-violet-400"
            title={
              block.minedAt ? `Добыт ${formatUtc(block.minedAt)}` : undefined
            }
          >
            <Gem className="size-2.5" />
            Добыт
            {block.minedHash && (
              <span className="text-violet-500">
                {block.minedHash.slice(0, 8)}…
              </span>
            )}
          </span>
        )}
        {block.miningStatus === "ready" && (
          <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-400">
            <Pickaxe className="size-2.5" />
            Готов к майнингу
          </span>
        )}
        {block.publication && (
          <span className="inline-flex items-center gap-1 rounded-sm border border-sky-700/60 bg-sky-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-sky-400">
            <Globe className="size-2.5" />
            Опубликован в сеть
          </span>
        )}
        <span className="ml-auto flex items-center gap-1.5">
          {dbAvailable && block.status === "ready" && block.publication && (
            <a
              href={block.publication.url}
              download
              className="inline-flex items-center gap-1 rounded-sm border border-sky-700/60 bg-sky-500/10 px-1.5 py-1 text-[9px] uppercase tracking-wider text-sky-400 transition-colors hover:bg-sky-500/25"
              title={`Постоянная публичная ссылка: ${block.publication.url}`}
            >
              <Globe className="size-2.5" />
              Публичная ссылка
            </a>
          )}
          {dbAvailable && block.status === "ready" && (
            <a
              href={`/api/blocks/${block.number}/download`}
              download
              className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-1.5 py-1 text-[9px] uppercase tracking-wider text-amber-400 transition-colors hover:bg-amber-500/25"
            >
              <Download className="size-2.5" />
              Скачать
            </a>
          )}
          <button
            type="button"
            onClick={() => onOpenBlock(block)}
            className="inline-flex items-center gap-1 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-1.5 py-1 text-[9px] uppercase tracking-wider text-emerald-400 transition-colors hover:bg-emerald-500/25"
          >
            <Crosshair className="size-2.5" />
            Перейти к блоку
          </button>
        </span>
      </div>

      {hasContent && (
        <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-emerald-600">
          <span className="uppercase tracking-wider text-emerald-800">
            Состав:
          </span>
          <span className="inline-flex items-center gap-1">
            <Globe className="size-3" />
            {content!.sites.length}{" "}
            {pluralForm(content!.sites.length, "сайт", "сайта", "сайтов")}
          </span>
          <span className="inline-flex items-center gap-1">
            <Newspaper className="size-3" />
            {content!.news.length}{" "}
            {pluralForm(content!.news.length, "новость", "новости", "новостей")}
          </span>
          <span className="inline-flex items-center gap-1">
            <FileText className="size-3" />
            {content!.files.length}{" "}
            {pluralForm(content!.files.length, "файл", "файла", "файлов")}
          </span>
        </div>
      )}

      {matched.length > 0 && (
        <div className="mt-1.5 space-y-0.5 border-t border-emerald-900/30 pt-1.5">
          <span className="uppercase tracking-wider text-amber-600">
            Найдено по содержимому:
          </span>
          {matched.map((item) => {
            const Icon = KIND_ICON[item.kind];
            return (
              <div
                key={item.url}
                className="flex flex-wrap items-center gap-x-1.5 leading-snug text-amber-500/90"
              >
                <Icon className="size-3 shrink-0" />
                <span className="text-amber-400">{item.title}</span>
                <span className="text-amber-800">
                  ({KIND_LABEL[item.kind]})
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
