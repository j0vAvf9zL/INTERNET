"use client";

import {
  useCallback,
  useEffect,
  useRef,
  useState,
  useSyncExternalStore,
} from "react";
import { toast } from "sonner";
import {
  ArrowUp,
  Boxes,
  Check,
  ChevronDown,
  CircleDot,
  Coins,
  Copy,
  Download,
  ExternalLink,
  Factory,
  FileText,
  Gem,
  Globe,
  HardDrive,
  Loader2,
  Network,
  Newspaper,
  PackageCheck,
  Pickaxe,
  ScrollText,
  Send,
  Sparkles,
  Terminal,
  Zap,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type {
  BlockRecord,
  BlockStats,
  FactoryState,
  MinerLogEntry,
  MinerState,
  MiningResult,
} from "@/lib/models";
import type { ArchiveContentItem, BlockContent } from "@/lib/archive";
import { BlockSearch } from "@/components/block-search";
import { MinerPanel } from "@/components/miner-panel";

function hasBlockContent(content?: BlockContent): content is BlockContent {
  return (
    !!content &&
    (content.sites.length > 0 ||
      content.news.length > 0 ||
      content.files.length > 0)
  );
}

function blockContentItems(content: BlockContent): ArchiveContentItem[] {
  return [...content.sites, ...content.news, ...content.files];
}

const numberFormat = new Intl.NumberFormat("ru-RU");
const percentFormat = new Intl.NumberFormat("ru-RU", {
  minimumFractionDigits: 6,
  maximumFractionDigits: 6,
});
const compactFormat = new Intl.NumberFormat("ru-RU", {
  notation: "compact",
  maximumFractionDigits: 2,
});
const petabytesFormat = new Intl.NumberFormat("ru-RU", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

type LogTone = "info" | "ok" | "warn";

interface LogLine {
  time: string;
  text: string;
  tone: LogTone;
}

interface TerminalMeta {
  productName: string;
  version: string;
  mode: string;
}

interface BlockConsoleProps {
  initialStats: BlockStats;
  initialBlocks: BlockRecord[];
  dbAvailable: boolean;
  terminalMeta: TerminalMeta;
  initialFactory: FactoryState;
  initialLog: LogLine[];
  initialMiner: MinerState;
  initialMiningResults: MiningResult[];
  initialMinerLogs: MinerLogEntry[];
  initialMinerQueueCount: number;
}

function formatUtc(iso: string): string {
  return iso
    .replace("T", " ")
    .replace(/\.\d{3}Z$/, "")
    .concat(" UTC");
}

function nowClock(): string {
  return new Date().toISOString().split("T")[1].slice(0, 8);
}

function formatRate(bps: number): string {
  if (bps < 1) {
    const seconds = 1 / bps;
    const label = Number.isInteger(seconds)
      ? String(seconds)
      : seconds.toFixed(1);
    return `1 блок / ${label} с`;
  }
  return `${bps} блок/с`;
}

function pluralForm(n: number, one: string, few: string, many: string): string {
  const abs = Math.abs(n) % 100;
  const last = abs % 10;
  if (abs > 10 && abs < 20) return many;
  if (last === 1) return one;
  if (last >= 2 && last <= 4) return few;
  return many;
}

function describeContent(content: BlockContent): string {
  const parts: string[] = [];
  if (content.sites.length > 0) {
    parts.push(
      `${content.sites.length} ${pluralForm(content.sites.length, "сайт", "сайта", "сайтов")}`
    );
  }
  if (content.news.length > 0) {
    parts.push(
      `${content.news.length} ${pluralForm(content.news.length, "новость", "новости", "новостей")}`
    );
  }
  if (content.files.length > 0) {
    parts.push(
      `${content.files.length} ${pluralForm(content.files.length, "файл", "файла", "файлов")}`
    );
  }
  return parts.join(" · ");
}

type ContentGroupKey = "sites" | "news" | "files";

const CONTENT_GROUP_LABEL: Record<ContentGroupKey, string> = {
  sites: "сайты",
  news: "новости",
  files: "файлы",
};

// Состав блока в истории: счётчики сайтов/новостей/файлов и раскрываемый
// список конкретных элементов из Интернет-архива. Показывается у каждого
// блока, независимо от источника (ручной/фабрика); если состав не сохранился,
// выводится фолбэк-строка.
function BlockComposition({ content }: { content?: BlockContent }) {
  if (!hasBlockContent(content)) {
    return (
      <div className="col-span-2 flex flex-wrap items-center gap-x-3 gap-y-1 border-t border-emerald-900/40 pt-1.5 text-[10px] text-emerald-700 sm:col-span-3">
        <span className="uppercase tracking-wider text-emerald-800">
          Состав:
        </span>
        <span className="italic text-emerald-800">состав не зафиксирован</span>
      </div>
    );
  }

  return (
    <details
      open
      className="group col-span-2 border-t border-emerald-900/40 pt-1.5 text-[10px] text-emerald-700 sm:col-span-3"
    >
      <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-3 gap-y-1">
        <span className="uppercase tracking-wider text-emerald-800">
          Состав:
        </span>
        <span className="inline-flex items-center gap-1 text-emerald-500">
          <Globe className="size-3" />
          {content.sites.length}{" "}
          {pluralForm(content.sites.length, "сайт", "сайта", "сайтов")}
        </span>
        <span className="inline-flex items-center gap-1 text-emerald-500">
          <Newspaper className="size-3" />
          {content.news.length}{" "}
          {pluralForm(content.news.length, "новость", "новости", "новостей")}
        </span>
        <span className="inline-flex items-center gap-1 text-emerald-500">
          <FileText className="size-3" />
          {content.files.length}{" "}
          {pluralForm(content.files.length, "файл", "файла", "файлов")}
        </span>
        <ChevronDown className="ml-auto size-3 shrink-0 text-emerald-800 transition-transform group-open:rotate-180" />
      </summary>
      <ul className="mt-1.5 space-y-0.5 border-t border-emerald-900/30 pt-1.5">
        {(["sites", "news", "files"] as const).map((group) => {
          const items = content[group];
          if (items.length === 0) return null;
          return (
            <li
              key={group}
              className="flex flex-wrap gap-x-2 gap-y-0.5 leading-snug"
            >
              <span className="uppercase tracking-wider text-emerald-800">
                {CONTENT_GROUP_LABEL[group]}:
              </span>
              <span className="text-emerald-600">
                {items.map((item) => item.title).join("; ")}
              </span>
            </li>
          );
        })}
      </ul>
    </details>
  );
}

function PanelTitle({
  icon,
  children,
}: {
  icon: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-emerald-600">
      {icon}
      {children}
    </div>
  );
}

// Статус готовности блока к майнингу и действие подготовки для майнера.
// not_ready — блок ещё генерируется; ready — можно подготовить; preparing —
// подготовка идёт; prepared — блок подготовлен и доступен для передачи.
function MiningStatusBadge({
  block,
  dbAvailable,
  busy,
  onPrepare,
}: {
  block: BlockRecord;
  dbAvailable: boolean;
  busy: boolean;
  onPrepare: (block: BlockRecord) => void;
}) {
  const { miningStatus } = block;

  if (miningStatus === "not_ready") {
    return (
      <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-900/60 bg-black/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-700">
        <CircleDot className="size-2.5" />
        Майнинг: ожидание
      </span>
    );
  }

  if (miningStatus === "ready") {
    return (
      <>
        <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-400">
          <Pickaxe className="size-2.5" />
          Готов к майнингу
        </span>
        {dbAvailable && (
          <button
            type="button"
            onClick={() => onPrepare(block)}
            disabled={busy}
            className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-amber-400 transition-colors hover:bg-amber-500/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 disabled:cursor-not-allowed disabled:opacity-60"
          >
            <Pickaxe className="size-3" />
            Подготовить
          </button>
        )}
      </>
    );
  }

  if (miningStatus === "preparing") {
    return (
      <span className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-amber-400">
        <Loader2 className="size-2.5 animate-spin" />
        Подготовка...
      </span>
    );
  }

  if (miningStatus === "mined") {
    return (
      <>
        <span
          className="inline-flex items-center gap-1 rounded-sm border border-violet-700/60 bg-violet-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-violet-400"
          title={
            block.minedAt ? `Добыт ${formatUtc(block.minedAt)}` : undefined
          }
        >
          <Gem className="size-2.5" />
          Добыт
        </span>
        {block.minedHash && (
          <span className="inline-flex items-center gap-1 text-[9px] text-emerald-600">
            hash {block.minedHash.slice(0, 12)}…
            {block.minedNonce !== undefined && (
              <span className="text-emerald-800">
                nonce {numberFormat.format(block.minedNonce)}
              </span>
            )}
          </span>
        )}
      </>
    );
  }

  return (
    <>
      <span className="inline-flex items-center gap-1 rounded-sm border border-cyan-700/60 bg-cyan-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-cyan-400">
        <PackageCheck className="size-2.5" />
        Подготовлен
      </span>
      {dbAvailable && (
        <a
          href={`/api/blocks/${block.number}/transfer`}
          download
          className="inline-flex items-center gap-1 rounded-sm border border-cyan-600/60 bg-cyan-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-cyan-400 transition-colors hover:bg-cyan-500/25"
        >
          <Send className="size-3" />
          Передать
        </a>
      )}
    </>
  );
}

function shortHex(value: string, head = 12, tail = 6): string {
  if (value.length <= head + tail + 3) return value;
  return `${value.slice(0, head)}…${value.slice(-tail)}`;
}

// Статус выпуска блока в сеть Ethereum. Блок без токена показывает статус
// «не выпущен» и кнопку «Выпустить в сеть Ethereum»; после выпуска блок
// получает уникальный токен-сертификат и статус «выпущен».
function BlockTokenBadge({
  block,
  dbAvailable,
  busy,
  onTokenize,
}: {
  block: BlockRecord;
  dbAvailable: boolean;
  busy: boolean;
  onTokenize: (block: BlockRecord) => void;
}) {
  const { token } = block;

  if (!token) {
    return (
      <>
        <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-800/60 bg-black/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-600">
          <Network className="size-2.5" />
          Не выпущен в сеть Ethereum
        </span>
        {dbAvailable && block.status === "ready" && (
          <button
            type="button"
            onClick={() => onTokenize(block)}
            disabled={busy}
            className="inline-flex items-center gap-1 rounded-sm border border-emerald-600/60 bg-emerald-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-emerald-400 transition-colors hover:bg-emerald-500/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500/50 disabled:cursor-not-allowed disabled:opacity-60"
          >
            {busy ? (
              <Loader2 className="size-3 animate-spin" />
            ) : (
              <Sparkles className="size-3" />
            )}
            Выпустить в сеть Ethereum
          </button>
        )}
      </>
    );
  }

  return (
    <span
      className="inline-flex items-center gap-1 rounded-sm border border-blue-700/60 bg-blue-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-blue-400"
      title={
        token.issuedAt ? `Выпущен ${formatUtc(token.issuedAt)}` : undefined
      }
    >
      <Network className="size-2.5" />
      Выпущен в сеть Ethereum
    </span>
  );
}

// Детали токена блока: номер токена, хеш содержимого, адрес контракта,
// хеш транзакции и ссылка на проводник.
function BlockTokenDetails({ block }: { block: BlockRecord }) {
  const { token } = block;
  if (!token) return null;

  return (
    <details
      open
      className="group col-span-2 border-t border-emerald-900/40 pt-1.5 text-[10px] text-emerald-700 sm:col-span-3"
    >
      <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-3 gap-y-1">
        <span className="uppercase tracking-wider text-emerald-800">
          Токен Ethereum:
        </span>
        <span className="inline-flex items-center gap-1 text-blue-500">
          <Boxes className="size-3" />#{numberFormat.format(token.tokenId)}
        </span>
        <span className="inline-flex items-center gap-1 text-emerald-500">
          <Network className="size-3" />
          {token.status === "issued" ? "выпущен в сеть" : token.status}
        </span>
        <ChevronDown className="ml-auto size-3 shrink-0 text-emerald-800 transition-transform group-open:rotate-180" />
      </summary>
      <ul className="mt-1.5 space-y-1 border-t border-emerald-900/30 pt-1.5 leading-snug">
        <li className="flex flex-wrap gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">
            хеш содержимого:
          </span>
          <span className="text-emerald-500" title={token.contentHash}>
            {shortHex(token.contentHash)}
          </span>
        </li>
        <li className="flex flex-wrap gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">
            контракт:
          </span>
          <span className="text-emerald-500" title={token.contractAddress}>
            {shortHex(token.contractAddress)}
          </span>
        </li>
        <li className="flex flex-wrap gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">tx:</span>
          <span className="text-emerald-500" title={token.txHash}>
            {shortHex(token.txHash)}
          </span>
        </li>
        <li className="flex flex-wrap items-center gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">
            проводник:
          </span>
          <a
            href={token.explorerUrl}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1 text-blue-500 underline decoration-blue-800 underline-offset-2 transition-colors hover:text-blue-400"
          >
            etherscan.io
            <ExternalLink className="size-2.5" />
          </a>
        </li>
      </ul>
    </details>
  );
}

// Статус публикации блока в сеть Интернет. Каждый выпущенный блок автоматически
// получает постоянную публичную ссылку на файл и статус «Опубликован в сеть».
function BlockPublicationBadge({ block }: { block: BlockRecord }) {
  const { publication } = block;
  if (!publication) return null;

  return (
    <span
      className="inline-flex items-center gap-1 rounded-sm border border-sky-700/60 bg-sky-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-sky-400"
      title={
        publication.publishedAt
          ? `Опубликован ${formatUtc(publication.publishedAt)}`
          : undefined
      }
    >
      <Globe className="size-2.5" />
      Опубликован в сеть
    </span>
  );
}

// Постоянная публичная ссылка блока в истории: адрес, по которому любой человек
// может скачать файл блока, статус «Опубликован в сеть» и детали публикации.
const emptySubscribe = () => () => {};

function getWindowOriginSnapshot(): string {
  return typeof window === "undefined" ? "" : window.location.origin;
}

function getWindowOriginServerSnapshot(): string {
  return "";
}

function BlockPublicationDetails({ block }: { block: BlockRecord }) {
  const { publication } = block;
  const [copied, setCopied] = useState(false);
  const origin = useSyncExternalStore(
    emptySubscribe,
    getWindowOriginSnapshot,
    getWindowOriginServerSnapshot
  );

  if (!publication) return null;

  const publicUrl = origin ? `${origin}${publication.url}` : publication.url;

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(publicUrl);
      setCopied(true);
      toast.success("Публичная ссылка скопирована");
      window.setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("Не удалось скопировать ссылку");
    }
  };

  return (
    <details
      open
      className="group col-span-2 border-t border-emerald-900/40 pt-1.5 text-[10px] text-emerald-700 sm:col-span-3"
    >
      <summary className="flex cursor-pointer list-none flex-wrap items-center gap-x-3 gap-y-1">
        <span className="uppercase tracking-wider text-emerald-800">
          Публичная ссылка:
        </span>
        <span className="inline-flex items-center gap-1 text-sky-500">
          <Globe className="size-3" />
          {publication.url}
        </span>
        <span className="inline-flex items-center gap-1 text-emerald-500">
          {publication.status === "published"
            ? "опубликован в сеть"
            : publication.status}
        </span>
        <ChevronDown className="ml-auto size-3 shrink-0 text-emerald-800 transition-transform group-open:rotate-180" />
      </summary>
      <ul className="mt-1.5 space-y-1 border-t border-emerald-900/30 pt-1.5 leading-snug">
        <li className="flex flex-wrap items-center gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">
            ссылка:
          </span>
          <a
            href={publication.url}
            download
            className="inline-flex items-center gap-1 break-all text-sky-500 underline decoration-sky-800 underline-offset-2 transition-colors hover:text-sky-400"
            title={publicUrl}
          >
            {publicUrl || publication.url}
            <Download className="size-2.5 shrink-0" />
          </a>
          <button
            type="button"
            onClick={copyLink}
            className="inline-flex items-center gap-1 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-400 transition-colors hover:bg-emerald-500/25"
            title="Скопировать публичную ссылку"
          >
            {copied ? (
              <Check className="size-2.5" />
            ) : (
              <Copy className="size-2.5" />
            )}
            {copied ? "Скопировано" : "Копировать"}
          </button>
        </li>
        <li className="flex flex-wrap gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">
            опубликован:
          </span>
          <span className="text-emerald-500">
            {formatUtc(publication.publishedAt)}
          </span>
        </li>
        <li className="flex flex-wrap gap-x-2">
          <span className="uppercase tracking-wider text-emerald-800">
            хеш содержимого:
          </span>
          <span className="text-emerald-500" title={publication.contentHash}>
            {shortHex(publication.contentHash)}
          </span>
        </li>
      </ul>
    </details>
  );
}

export function BlockConsole({
  initialStats,
  initialBlocks,
  dbAvailable,
  terminalMeta,
  initialFactory,
  initialLog,
  initialMiner,
  initialMiningResults,
  initialMinerLogs,
  initialMinerQueueCount,
}: BlockConsoleProps) {
  const [stats, setStats] = useState<BlockStats>(initialStats);
  const [blocks, setBlocks] = useState<BlockRecord[]>(initialBlocks);
  const [factory, setFactory] = useState<FactoryState>(initialFactory);
  const [log, setLog] = useState<LogLine[]>(initialLog);
  const [releasing, setReleasing] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const [preparingNumbers, setPreparingNumbers] = useState<Set<number>>(
    () => new Set()
  );
  const [tokenizingNumbers, setTokenizingNumbers] = useState<Set<number>>(
    () => new Set()
  );
  const [exactValues, setExactValues] = useState(false);
  const [highlightedNumber, setHighlightedNumber] = useState<number | null>(
    null
  );
  const factoryMaxNumberRef = useRef<number | null>(null);

  const pushLog = useCallback((text: string, tone: LogTone = "info") => {
    setLog((prev) => [...prev, { time: nowClock(), text, tone }].slice(-9));
  }, []);

  const detectFactoryProduction = useCallback(
    (list: BlockRecord[]) => {
      const factoryBlocks = list.filter((block) => block.source === "factory");
      if (factoryBlocks.length === 0) return;

      const maxNumber = Math.max(...factoryBlocks.map((block) => block.number));

      if (factoryMaxNumberRef.current === null) {
        factoryMaxNumberRef.current = maxNumber;
        return;
      }

      const newOnes = factoryBlocks
        .filter((block) => block.number > factoryMaxNumberRef.current!)
        .sort((a, b) => b.number - a.number);

      if (newOnes.length === 0) return;

      for (const block of newOnes.slice(0, 5)) {
        pushLog(
          `ФАБРИКА: ВЫПУЩЕН БЛОК #${String(block.number).padStart(9, "0")} [${block.sizeGb} ГБ] — OK`,
          "ok"
        );
      }

      factoryMaxNumberRef.current = maxNumber;
    },
    [pushLog]
  );

  const refresh = useCallback(async () => {
    const [blocksResponse, factoryResponse] = await Promise.all([
      fetch("/api/blocks"),
      fetch("/api/factory").catch(() => null),
    ]);

    if (blocksResponse.ok) {
      const data = await blocksResponse.json();
      if (data && typeof data === "object") {
        if (data.stats) setStats(data.stats);
        if (Array.isArray(data.blocks)) {
          setBlocks(data.blocks);
          detectFactoryProduction(data.blocks);
        }
      }
    }

    if (factoryResponse?.ok) {
      const data = await factoryResponse.json();
      if (data?.factory) setFactory(data.factory);
    }
  }, [detectFactoryProduction]);

  useEffect(() => {
    const factoryBlocks = initialBlocks.filter(
      (block) => block.source === "factory"
    );
    if (factoryBlocks.length > 0) {
      factoryMaxNumberRef.current = Math.max(
        ...factoryBlocks.map((block) => block.number)
      );
      for (const block of factoryBlocks.slice(0, 2)) {
        pushLog(
          `ФАБРИКА: ВЫПУЩЕН БЛОК #${String(block.number).padStart(9, "0")} [${block.sizeGb} ГБ] — OK`,
          "ok"
        );
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!dbAvailable) return;
    const interval = setInterval(refresh, 4000);
    return () => clearInterval(interval);
  }, [dbAvailable, refresh]);

  const handleOpenBlock = useCallback((block: BlockRecord) => {
    setBlocks((prev) =>
      prev.some((existing) => existing.number === block.number)
        ? prev
        : [block, ...prev]
    );
    setHighlightedNumber(block.number);
    window.setTimeout(() => {
      document
        .getElementById(`block-entry-${block.number}`)
        ?.scrollIntoView({ behavior: "smooth", block: "center" });
    }, 60);
    window.setTimeout(() => setHighlightedNumber(null), 3000);
  }, []);

  const handleRelease = async () => {
    if (releasing) return;
    setReleasing(true);
    const id = toast.loading("Создаём блок на 10 ГБ...");
    try {
      const response = await fetch("/api/blocks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const block: BlockRecord = await response.json();
        pushLog(
          `ВЫПУЩЕН БЛОК #${String(block.number).padStart(9, "0")} [${block.sizeGb} ГБ] — OK`,
          "ok"
        );
        if (block.token) {
          pushLog(
            `ETH: БЛОК #${String(block.number).padStart(9, "0")} ВЫПУЩЕН В СЕТЬ — ТОКЕН #${numberFormat.format(block.token.tokenId)} — OK`,
            "info"
          );
        }
        if (block.publication) {
          pushLog(
            `СЕТЬ: БЛОК #${String(block.number).padStart(9, "0")} ОПУБЛИКОВАН В ИНТЕРНЕТ — ${block.publication.url} — OK`,
            "ok"
          );
        }
        if (hasBlockContent(block.content)) {
          const items = blockContentItems(block.content!);
          const bytes = items.reduce((sum, item) => sum + item.byteLength, 0);
          pushLog(
            `ИЗ АРХИВА: ${describeContent(block.content!)} (${numberFormat.format(bytes)} Б)`,
            "info"
          );
        }
        await refresh();
        toast.success(`Блок #${numberFormat.format(block.number)} выпущен`, {
          id,
        });
      } else {
        const error = await response.json().catch(() => null);
        toast.error(error?.error || "Ошибка выпуска блока", { id });
      }
    } catch {
      toast.error("Ошибка соединения с сервером", { id });
    } finally {
      setReleasing(false);
    }
  };

  const handleUpgrade = async () => {
    if (upgrading || !dbAvailable) return;
    setUpgrading(true);
    const id = toast.loading("Улучшаем фабрику...");
    try {
      const response = await fetch("/api/factory", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({}),
      });

      if (response.ok) {
        const data = await response.json();
        setFactory(data.factory);
        pushLog(
          `ФАБРИКА: УРОВЕНЬ ${data.factory.level} — СКОРОСТЬ ${formatRate(data.factory.blocksPerSecond)} — OK`,
          "ok"
        );
        await refresh();
        toast.success(`Фабрика улучшена до уровня ${data.factory.level}`, {
          id,
        });
      } else {
        const error = await response.json().catch(() => null);
        toast.error(error?.error || "Ошибка улучшения фабрики", { id });
      }
    } catch {
      toast.error("Ошибка соединения с сервером", { id });
    } finally {
      setUpgrading(false);
    }
  };

  const handlePrepare = useCallback(
    async (block: BlockRecord) => {
      if (!dbAvailable || preparingNumbers.has(block.number)) return;
      setPreparingNumbers((prev) => new Set(prev).add(block.number));
      const id = toast.loading(
        `Подготавливаем блок #${numberFormat.format(block.number)} к майнеру...`
      );
      try {
        const response = await fetch(`/api/blocks/${block.number}/prepare`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({}),
        });

        if (response.ok) {
          const data = await response.json();
          if (data?.block) {
            setBlocks((prev) =>
              prev.map((entry) =>
                entry.number === data.block.number ? data.block : entry
              )
            );
            pushLog(
              `МАЙНИНГ: БЛОК #${String(data.block.number).padStart(9, "0")} ПОДГОТОВЛЕН К МАЙНЕРУ — OK`,
              "ok"
            );
          }
          toast.success(
            `Блок #${numberFormat.format(block.number)} подготовлен к майнингу`,
            { id }
          );
          await refresh();
        } else {
          const error = await response.json().catch(() => null);
          toast.error(error?.error || "Ошибка подготовки блока", { id });
        }
      } catch {
        toast.error("Ошибка соединения с сервером", { id });
      } finally {
        setPreparingNumbers((prev) => {
          const next = new Set(prev);
          next.delete(block.number);
          return next;
        });
      }
    },
    [dbAvailable, preparingNumbers, pushLog, refresh]
  );

  const handleTokenize = useCallback(
    async (block: BlockRecord) => {
      if (!dbAvailable || tokenizingNumbers.has(block.number)) return;
      setTokenizingNumbers((prev) => new Set(prev).add(block.number));
      const id = toast.loading(
        `Выпускаем блок #${numberFormat.format(block.number)} в сеть Ethereum...`
      );
      try {
        const response = await fetch(`/api/blocks/${block.number}/tokenize`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({}),
        });

        if (response.ok) {
          const data = await response.json();
          if (data?.block) {
            setBlocks((prev) =>
              prev.map((entry) =>
                entry.number === data.block.number ? data.block : entry
              )
            );
            pushLog(
              `ETH: БЛОК #${String(data.block.number).padStart(9, "0")} ВЫПУЩЕН В СЕТЬ — ТОКЕН #${numberFormat.format(data.block.token?.tokenId ?? data.block.number)} — OK`,
              "ok"
            );
          }
          toast.success(
            `Блок #${numberFormat.format(block.number)} выпущен в сеть Ethereum`,
            { id }
          );
          await refresh();
        } else {
          const error = await response.json().catch(() => null);
          toast.error(error?.error || "Ошибка выпуска в сеть Ethereum", {
            id,
          });
        }
      } catch {
        toast.error("Ошибка соединения с сервером", { id });
      } finally {
        setTokenizingNumbers((prev) => {
          const next = new Set(prev);
          next.delete(block.number);
          return next;
        });
      }
    },
    [dbAvailable, tokenizingNumbers, pushLog, refresh]
  );

  const percent = (stats.released / stats.target) * 100;
  const totalVolumePb = (stats.released * stats.blockSizeGb) / 1_000_000;
  const releasedLabel = exactValues
    ? numberFormat.format(stats.released)
    : compactFormat.format(stats.released);
  const targetLabel = exactValues
    ? numberFormat.format(stats.target)
    : compactFormat.format(stats.target);
  const volumeLabel = exactValues
    ? `${numberFormat.format(stats.totalBytes)} байт`
    : `${petabytesFormat.format(totalVolumePb)} ПБ`;
  const atMaxLevel = factory.level >= factory.maxLevel;
  const canAfford = factory.coins >= factory.upgradePrice;
  const upgradeDisabled = !dbAvailable || upgrading || atMaxLevel || !canAfford;

  return (
    <div className="min-h-[calc(100vh-8rem)] bg-[#030605] px-4 py-8 font-mono text-emerald-400 sm:px-6">
      <div className="mx-auto max-w-6xl overflow-hidden rounded-lg border border-emerald-900/70 bg-[#070c09] shadow-[0_0_60px_rgba(16,185,129,0.08)]">
        <div className="flex items-center gap-2 border-b border-emerald-900/70 bg-[#0a100c] px-4 py-2.5">
          <span className="size-2.5 rounded-full bg-[#ff5f56]" />
          <span className="size-2.5 rounded-full bg-[#ffbd2e]" />
          <span className="size-2.5 rounded-full bg-[#27c93f]" />
          <span className="ml-3 text-[11px] uppercase tracking-[0.2em] text-emerald-700">
            {terminalMeta.productName} — генератор {terminalMeta.version}
          </span>
          <span className="ml-auto hidden text-[11px] text-emerald-800 sm:block">
            root@blocks-internet:~$
          </span>
        </div>

        <div className="grid gap-0 lg:grid-cols-[1.05fr_0.95fr]">
          <div className="space-y-6 border-b border-emerald-900/50 p-5 sm:p-7 lg:border-r">
            <section className="space-y-3">
              <div className="flex items-center justify-between gap-3">
                <PanelTitle icon={<CircleDot className="size-3.5" />}>
                  Выпущено блоков
                </PanelTitle>
                <button
                  type="button"
                  onClick={() => setExactValues((value) => !value)}
                  title={
                    exactValues
                      ? "Показать сокращённо"
                      : "Показать точные значения"
                  }
                  className={cn(
                    "rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-[0.2em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50",
                    exactValues
                      ? "border-amber-600/60 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                      : "border-emerald-800/70 bg-emerald-950/40 text-emerald-600 hover:text-emerald-400"
                  )}
                >
                  {exactValues ? "Сокращённо" : "Точные значения"}
                </button>
              </div>
              <div
                className="text-4xl font-bold tracking-tight text-emerald-300 tabular-nums sm:text-6xl"
                title={
                  exactValues
                    ? undefined
                    : `Точное значение: ${numberFormat.format(stats.released)}`
                }
              >
                {releasedLabel}
              </div>
              <div className="text-sm text-emerald-700">
                из цели{" "}
                <span
                  className="font-semibold text-amber-500 tabular-nums"
                  title={
                    exactValues
                      ? undefined
                      : `Точное значение: ${numberFormat.format(stats.target)}`
                  }
                >
                  {targetLabel}
                </span>
                <span className="ml-2 text-amber-500/80 tabular-nums">
                  ({percentFormat.format(percent)} %)
                </span>
              </div>
            </section>

            <section className="space-y-2">
              <div className="flex items-center justify-between text-[11px] uppercase tracking-[0.25em] text-emerald-600">
                <span>Прогресс</span>
                <span className="text-amber-500 tabular-nums">
                  {percentFormat.format(percent)} %
                </span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-none border border-emerald-900 bg-black/60">
                <div
                  className="h-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-emerald-300"
                  style={{ width: `${percent}%`, minWidth: 2 }}
                />
              </div>
              <p className="text-xs text-emerald-700">
                суммарный объём:{" "}
                <span
                  className="text-emerald-400 tabular-nums"
                  title={
                    exactValues
                      ? undefined
                      : `Точное значение: ${numberFormat.format(stats.totalBytes)} байт`
                  }
                >
                  {volumeLabel}
                </span>
              </p>
            </section>

            <section className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
              <button
                type="button"
                onClick={handleRelease}
                disabled={!dbAvailable || releasing}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-sm border border-amber-500/70 bg-amber-500/10 px-6 text-sm font-semibold uppercase tracking-[0.2em] text-amber-400 transition-colors hover:bg-amber-500/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-50"
              >
                {releasing ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  <Zap className="size-4" />
                )}
                {releasing ? "Создание..." : "Выпустить блок"}
              </button>
              <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.2em] text-emerald-700">
                <HardDrive className="size-3.5" />1 блок = {stats.blockSizeGb}{" "}
                ГБ данных
              </div>
            </section>

            {!dbAvailable && (
              <p className="rounded-sm border border-amber-800/60 bg-amber-950/30 px-3 py-2 text-xs text-amber-500/90">
                База данных недоступна — выпуск отключён, показаны статические
                данные.
              </p>
            )}

            <section className="space-y-3 rounded-sm border border-emerald-900/70 bg-black/30 p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-emerald-500">
                  <Factory className="size-4" />
                  Автоматическая фабрика
                </div>
                <span
                  className={cn(
                    "inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-[0.2em]",
                    dbAvailable
                      ? "border-emerald-700/60 bg-emerald-500/10 text-emerald-400"
                      : "border-amber-700/60 bg-amber-500/10 text-amber-500"
                  )}
                >
                  <span
                    className={cn(
                      "size-1.5 animate-pulse rounded-full",
                      dbAvailable ? "bg-emerald-400" : "bg-amber-500"
                    )}
                  />
                  {dbAvailable ? "Онлайн" : "Офлайн"}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    Уровень
                  </div>
                  <div className="text-2xl font-bold text-emerald-300 tabular-nums">
                    {factory.level}
                    <span className="ml-1 text-sm font-normal text-emerald-700">
                      / {factory.maxLevel}
                    </span>
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    Скорость
                  </div>
                  <div className="text-2xl font-bold text-amber-400 tabular-nums">
                    {formatRate(factory.blocksPerSecond)}
                  </div>
                </div>
                <div>
                  <div className="flex items-center gap-1 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    <Coins className="size-3" />
                    Монеты
                  </div>
                  <div className="text-2xl font-bold text-emerald-300 tabular-nums">
                    {numberFormat.format(factory.coins)}
                  </div>
                </div>
                <div>
                  <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
                    Блоков фабрикой
                  </div>
                  <div className="text-2xl font-bold text-emerald-300 tabular-nums">
                    {compactFormat.format(factory.totalFactoryBlocks)}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={handleUpgrade}
                disabled={upgradeDisabled}
                title={
                  atMaxLevel
                    ? "Достигнут максимальный уровень"
                    : !canAfford
                      ? `Не хватает ${numberFormat.format(factory.upgradePrice - factory.coins)} монет`
                      : undefined
                }
                className={cn(
                  "inline-flex h-9 w-full items-center justify-center gap-2 rounded-sm border px-4 text-xs font-semibold uppercase tracking-[0.2em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60",
                  atMaxLevel
                    ? "border-emerald-800/60 bg-emerald-950/30 text-emerald-600"
                    : canAfford
                      ? "border-amber-500/70 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
                      : "border-emerald-700/60 bg-emerald-500/5 text-emerald-500"
                )}
              >
                {upgrading ? (
                  <Loader2 className="size-3.5 animate-spin" />
                ) : (
                  <ArrowUp className="size-3.5" />
                )}
                {atMaxLevel
                  ? "Макс. уровень"
                  : `Улучшить скорость — ${numberFormat.format(factory.upgradePrice)} монет`}
              </button>
            </section>

            <MinerPanel
              dbAvailable={dbAvailable}
              initialMiner={initialMiner}
              initialResults={initialMiningResults}
              initialLogs={initialMinerLogs}
              initialQueueCount={initialMinerQueueCount}
              onLog={pushLog}
              onMined={refresh}
            />
          </div>

          <div className="space-y-6 p-5 sm:p-7">
            <section className="space-y-3">
              <PanelTitle icon={<Terminal className="size-4" />}>
                Лог терминала
              </PanelTitle>
              <div className="max-h-64 overflow-y-auto rounded-sm border border-emerald-900/70 bg-black/50 p-4 text-xs leading-relaxed">
                {log.map((line, i) => (
                  <div key={i} className="flex gap-3 whitespace-pre-wrap">
                    <span className="shrink-0 text-amber-500/80 tabular-nums">
                      [{line.time}]
                    </span>
                    <span
                      className={cn(
                        line.tone === "ok" && "text-emerald-400",
                        line.tone === "warn" && "text-amber-400",
                        line.tone === "info" && "text-emerald-300/80"
                      )}
                    >
                      {line.text}
                    </span>
                  </div>
                ))}
                <div className="mt-1 flex items-center gap-1 text-emerald-500">
                  <span>&gt;</span>
                  <span className="inline-block h-3.5 w-2 animate-pulse bg-emerald-400" />
                </div>
              </div>
            </section>

            <BlockSearch
              dbAvailable={dbAvailable}
              onOpenBlock={handleOpenBlock}
            />

            <section className="space-y-3">
              <PanelTitle icon={<ScrollText className="size-4" />}>
                История выпусков
              </PanelTitle>
              <div className="divide-y divide-emerald-900/50 rounded-sm border border-emerald-900/70 bg-black/50">
                {blocks.length === 0 ? (
                  <div className="flex flex-col items-center gap-3 px-4 py-10 text-center">
                    <div className="flex size-12 items-center justify-center rounded-full bg-emerald-950/60">
                      <ScrollText className="size-6 text-emerald-700" />
                    </div>
                    <p className="text-sm text-emerald-700">
                      Блоки ещё не выпущены
                    </p>
                    {dbAvailable && (
                      <p className="text-xs text-emerald-800">
                        Нажмите «Выпустить блок», чтобы создать первый блок на
                        10 ГБ
                      </p>
                    )}
                  </div>
                ) : (
                  blocks.map((release) => (
                    <div
                      key={release.id}
                      id={`block-entry-${release.number}`}
                      className={cn(
                        "grid grid-cols-[auto_1fr] items-center gap-x-3 gap-y-1 px-4 py-2.5 text-xs sm:grid-cols-[auto_1fr_auto] sm:gap-y-0",
                        highlightedNumber === release.number &&
                          "bg-amber-500/10 outline outline-1 outline-amber-500/70"
                      )}
                    >
                      <span className="font-semibold text-amber-400 tabular-nums">
                        #{numberFormat.format(release.number)}
                      </span>
                      <span className="text-emerald-500/80">
                        {formatUtc(release.releasedAt)}
                      </span>
                      <div className="col-span-2 flex flex-wrap items-center gap-2 sm:col-span-1">
                        {release.source === "factory" ? (
                          <span className="inline-flex items-center gap-1 rounded-sm border border-emerald-800/60 bg-emerald-950/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-500">
                            <Factory className="size-2.5" />
                            Фабрика
                          </span>
                        ) : (
                          <span className="rounded-sm border border-emerald-900/60 bg-black/40 px-1.5 py-0.5 text-[9px] uppercase tracking-wider text-emerald-700">
                            Ручной
                          </span>
                        )}
                        <span className="text-emerald-400 tabular-nums">
                          {release.sizeGb} ГБ
                        </span>
                        <span className="text-emerald-800 tabular-nums">
                          ({numberFormat.format(release.sizeBytes)} байт)
                        </span>
                        {release.status === "generating" ? (
                          <span className="inline-flex items-center gap-1.5 rounded-sm border border-amber-600/60 bg-amber-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-amber-400">
                            <Loader2 className="size-3 animate-spin" />
                            Генерация...
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1.5 rounded-sm border border-emerald-700/60 bg-emerald-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-emerald-400">
                            <span className="size-1.5 rounded-full bg-emerald-400" />
                            Готов
                          </span>
                        )}
                        <MiningStatusBadge
                          block={release}
                          dbAvailable={dbAvailable}
                          busy={preparingNumbers.has(release.number)}
                          onPrepare={handlePrepare}
                        />
                        <BlockTokenBadge
                          block={release}
                          dbAvailable={dbAvailable}
                          busy={tokenizingNumbers.has(release.number)}
                          onTokenize={handleTokenize}
                        />
                        <BlockPublicationBadge block={release} />
                        {dbAvailable && release.status === "ready" && (
                          <a
                            href={`/api/blocks/${release.number}/download`}
                            download
                            className="inline-flex items-center gap-1 rounded-sm border border-amber-600/60 bg-amber-500/10 px-2 py-1 text-[10px] uppercase tracking-wider text-amber-400 transition-colors hover:bg-amber-500/25"
                          >
                            <Download className="size-3" />
                            Скачать
                          </a>
                        )}
                      </div>
                      <BlockTokenDetails block={release} />
                      <BlockPublicationDetails block={release} />
                      <BlockComposition content={release.content} />
                    </div>
                  ))
                )}
              </div>
            </section>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-x-5 gap-y-1 border-t border-emerald-900/70 bg-[#0a100c] px-4 py-2 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
          <span>
            статус: <span className="text-amber-500">{terminalMeta.mode}</span>
          </span>
          <span>
            режим:{" "}
            <span className="text-emerald-400">
              {dbAvailable ? "динамический" : "статический"}
            </span>
          </span>
          <span className="ml-auto hidden sm:block">uptime: 99:99:99</span>
          <span className="inline-block h-3 w-2 animate-pulse bg-emerald-500" />
        </div>
      </div>
    </div>
  );
}
