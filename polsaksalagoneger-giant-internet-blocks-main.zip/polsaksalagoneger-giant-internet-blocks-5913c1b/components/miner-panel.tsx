"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Gem, Loader2, Pickaxe, Play, Square, Terminal } from "lucide-react";
import { cn } from "@/lib/utils";
import type { MinerLogEntry, MinerState, MiningResult } from "@/lib/models";
import { MINING_DURATION_MS } from "@/lib/miner";

type LogTone = "info" | "ok" | "warn";

interface MinerPanelProps {
  dbAvailable: boolean;
  initialMiner: MinerState;
  initialResults: MiningResult[];
  initialLogs: MinerLogEntry[];
  initialQueueCount: number;
  onLog: (text: string, tone: LogTone) => void;
  onMined?: () => void;
}

const numberFormat = new Intl.NumberFormat("ru-RU");
const durationFormat = new Intl.NumberFormat("ru-RU", {
  maximumFractionDigits: 1,
});

function clockFromIso(iso: string): string {
  return iso.slice(11, 19);
}

function formatDuration(ms?: number): string {
  if (!ms) return "—";
  const seconds = ms / 1000;
  if (seconds < 60) return `${durationFormat.format(seconds)} с`;
  return `${durationFormat.format(seconds / 60)} мин`;
}

const TONE_CLASS: Record<LogTone, string> = {
  info: "text-emerald-300/80",
  ok: "text-emerald-400",
  warn: "text-amber-400",
};

export function MinerPanel({
  dbAvailable,
  initialMiner,
  initialResults,
  initialLogs,
  initialQueueCount,
  onLog,
  onMined,
}: MinerPanelProps) {
  const [miner, setMiner] = useState<MinerState>(initialMiner);
  const [results, setResults] = useState<MiningResult[]>(initialResults);
  const [logs, setLogs] = useState<MinerLogEntry[]>(initialLogs);
  const [queueCount, setQueueCount] = useState(initialQueueCount);
  const [busy, setBusy] = useState(false);
  const [nowTick, setNowTick] = useState(() => Date.now());
  const seenLogIdsRef = useRef<Set<string>>(new Set());
  const processedRef = useRef(initialMiner.processedBlocks);

  const applyMinerData = useCallback(
    (data: {
      miner?: MinerState;
      results?: MiningResult[];
      logs?: MinerLogEntry[];
      queueCount?: number;
    }) => {
      if (data.miner) {
        setMiner(data.miner);
        if (data.miner.processedBlocks > processedRef.current) {
          processedRef.current = data.miner.processedBlocks;
          onMined?.();
        }
      }
      if (typeof data.queueCount === "number") {
        setQueueCount(data.queueCount);
      }
      if (Array.isArray(data.results)) {
        setResults(data.results);
      }
      if (Array.isArray(data.logs)) {
        setLogs(data.logs);
        for (let i = data.logs.length - 1; i >= 0; i--) {
          const entry = data.logs[i];
          if (seenLogIdsRef.current.has(entry.id)) continue;
          seenLogIdsRef.current.add(entry.id);
          onLog(entry.text, entry.tone);
        }
        if (seenLogIdsRef.current.size > 60) {
          const arr = Array.from(seenLogIdsRef.current).slice(-40);
          seenLogIdsRef.current = new Set(arr);
        }
      }
    },
    [onLog, onMined]
  );

  const refresh = useCallback(async () => {
    try {
      const response = await fetch("/api/miner");
      if (response.ok) {
        const data = await response.json();
        applyMinerData(data);
      }
    } catch {
      void 0;
    }
  }, [applyMinerData]);

  useEffect(() => {
    if (!dbAvailable) return;
    void refresh();
    const interval = setInterval(refresh, 2000);
    const clock = setInterval(() => setNowTick(Date.now()), 1000);
    return () => {
      clearInterval(interval);
      clearInterval(clock);
    };
  }, [dbAvailable, refresh]);

  const handleAction = async (action: "start" | "stop") => {
    if (busy || !dbAvailable) return;
    setBusy(true);
    const id = toast.loading(
      action === "start" ? "Запускаем майнер..." : "Останавливаем майнер..."
    );
    try {
      const response = await fetch("/api/miner", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });

      if (response.ok) {
        const data = await response.json();
        if (data?.miner) setMiner(data.miner);
        toast.success(
          action === "start" ? "Майнер запущен" : "Майнер остановлен",
          { id }
        );
        await refresh();
      } else {
        const error = await response.json().catch(() => null);
        toast.error(error?.error || "Ошибка управления майнером", { id });
      }
    } catch {
      toast.error("Ошибка соединения с сервером", { id });
    } finally {
      setBusy(false);
    }
  };

  const running = miner.status === "running";
  const processing = results.find((result) => result.status === "processing");
  const progressPercent = processing
    ? Math.min(
        100,
        Math.max(
          0,
          ((nowTick - new Date(processing.startedAt).getTime()) /
            MINING_DURATION_MS) *
            100
        )
      )
    : 0;

  return (
    <section className="space-y-3 rounded-sm border border-emerald-900/70 bg-black/30 p-4">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-[11px] uppercase tracking-[0.25em] text-emerald-500">
          <Pickaxe className="size-4" />
          Панель майнера
        </div>
        <span
          className={cn(
            "inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 text-[10px] uppercase tracking-[0.2em]",
            running
              ? "border-emerald-700/60 bg-emerald-500/10 text-emerald-400"
              : "border-amber-700/60 bg-amber-500/10 text-amber-500"
          )}
        >
          <span
            className={cn(
              "size-1.5 animate-pulse rounded-full",
              running ? "bg-emerald-400" : "bg-amber-500"
            )}
          />
          {running ? "Работает" : "Простой"}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            Статус
          </div>
          <div
            className={cn(
              "text-2xl font-bold tabular-nums",
              running ? "text-emerald-300" : "text-amber-400"
            )}
          >
            {running ? "Добыча" : "Ожидание"}
          </div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            В очереди
          </div>
          <div className="text-2xl font-bold text-emerald-300 tabular-nums">
            {numberFormat.format(queueCount)}
          </div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            Обработано
          </div>
          <div className="text-2xl font-bold text-emerald-300 tabular-nums">
            {numberFormat.format(miner.processedBlocks)}
          </div>
        </div>
        <div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-emerald-700">
            Текущий блок
          </div>
          <div className="text-xl font-bold text-amber-400 tabular-nums">
            {miner.currentBlockNumber != null
              ? `#${numberFormat.format(miner.currentBlockNumber)}`
              : "—"}
          </div>
        </div>
      </div>

      {processing && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-[11px] text-amber-400">
            <Loader2 className="size-3 animate-spin" />
            <span>
              Добыча блока{" "}
              <span className="tabular-nums">
                #{numberFormat.format(processing.blockNumber)}
              </span>{" "}
              (сложность {processing.difficulty}…)
            </span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-none border border-emerald-900 bg-black/60">
            <div
              className="h-full bg-gradient-to-r from-amber-600 to-amber-400"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>
      )}

      <button
        type="button"
        onClick={() => handleAction(running ? "stop" : "start")}
        disabled={!dbAvailable || busy}
        className={cn(
          "inline-flex h-9 w-full items-center justify-center gap-2 rounded-sm border px-4 text-xs font-semibold uppercase tracking-[0.2em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-500/50 active:translate-y-px disabled:cursor-not-allowed disabled:opacity-60",
          running
            ? "border-amber-600/70 bg-amber-500/10 text-amber-400 hover:bg-amber-500/20"
            : "border-emerald-500/70 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20"
        )}
      >
        {busy ? (
          <Loader2 className="size-3.5 animate-spin" />
        ) : running ? (
          <Square className="size-3.5" />
        ) : (
          <Play className="size-3.5" />
        )}
        {running ? "Остановить майнер" : "Запустить майнер"}
      </button>

      {!dbAvailable && (
        <p className="rounded-sm border border-amber-800/60 bg-amber-950/30 px-3 py-2 text-[11px] text-amber-500/90">
          База данных недоступна — майнер отключён, показаны статические данные.
        </p>
      )}

      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
          <Terminal className="size-3" />
          Лог майнера
        </div>
        <div className="max-h-32 overflow-y-auto rounded-sm border border-emerald-900/70 bg-black/50 p-3 text-[11px] leading-relaxed">
          {logs.length === 0 ? (
            <p className="text-emerald-800">логов нет</p>
          ) : (
            logs.map((entry) => (
              <div key={entry.id} className="flex gap-2 whitespace-pre-wrap">
                <span className="shrink-0 text-amber-500/80 tabular-nums">
                  [{clockFromIso(entry.time)}]
                </span>
                <span className={TONE_CLASS[entry.tone]}>{entry.text}</span>
              </div>
            ))
          )}
        </div>
      </div>

      <div className="space-y-1.5">
        <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-[0.2em] text-emerald-700">
          <Gem className="size-3" />
          Результаты добычи
        </div>
        {results.length === 0 ? (
          <div className="flex flex-col items-center gap-2 rounded-sm border border-emerald-900/50 bg-black/30 px-4 py-5 text-center">
            <div className="flex size-9 items-center justify-center rounded-full bg-emerald-950/60">
              <Gem className="size-4 text-emerald-700" />
            </div>
            <p className="text-xs text-emerald-600">Добытых блоков пока нет</p>
            <p className="text-[11px] text-emerald-800">
              Подготовьте блоки и запустите майнер
            </p>
          </div>
        ) : (
          <ul className="space-y-1">
            {results.map((result) => (
              <li
                key={result.blockNumber}
                className="flex flex-wrap items-center gap-x-2 gap-y-0.5 border-t border-emerald-900/30 pt-1 text-[11px]"
              >
                <span className="font-semibold text-amber-400 tabular-nums">
                  #{numberFormat.format(result.blockNumber)}
                </span>
                {result.status === "processing" ? (
                  <span className="inline-flex items-center gap-1 text-amber-400">
                    <Loader2 className="size-2.5 animate-spin" />
                    добыча...
                  </span>
                ) : (
                  <>
                    <span className="text-emerald-500">
                      {result.hash?.slice(0, 12)}…
                    </span>
                    {result.nonce !== undefined && (
                      <span className="text-emerald-700">
                        nonce {numberFormat.format(result.nonce)}
                      </span>
                    )}
                  </>
                )}
                <span className="ml-auto text-emerald-800 tabular-nums">
                  {formatDuration(result.durationMs)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
