// Публикация блоков в сеть Интернет — встроенная.
// При выпуске блок автоматически получает постоянную публичную ссылку на файл
// и статус «Опубликован в сеть». Ссылка детерминирована по номеру блока,
// поэтому она стабильна и доступна для всех выпущенных блоков, включая те, что
// были созданы до введения публикации.

import { createHash } from "node:crypto";
import { blockContentItems, type BlockContent } from "./archive";

// Путь публичной ссылки на файл блока (относительный, от корня приложения).
export function publicBlockPath(number: number): string {
  return `/api/blocks/${number}/public`;
}

export type PublicationStatus = "published";

export interface PublicationCertificate {
  // Постоянная публичная ссылка на файл блока. Относительная, чтобы оставаться
  // рабочей независимо от хоста (локальный dev / удалённый HTTPS-прокси);
  // полный абсолютный адрес собирается на клиенте через window.location.origin.
  url: string;
  publishedAt: string;
  status: PublicationStatus;
  contentHash: string;
}

export interface PublishInput {
  number: number;
  sizeBytes: number;
  fileName: string;
  content?: BlockContent;
}

function publicationPayload(input: PublishInput): string {
  const items = input.content
    ? blockContentItems(input.content)
        .map((item) => ({
          kind: item.kind,
          title: item.title,
          url: item.url,
          byteLength: item.byteLength,
          sha1: item.sha1 ?? "",
        }))
        .sort((a, b) => a.url.localeCompare(b.url))
    : [];
  return JSON.stringify({
    format: "blocks-internet-publication/v1",
    number: input.number,
    sizeBytes: input.sizeBytes,
    fileName: input.fileName,
    items,
  });
}

// Детерминированный хеш публикуемого содержимого: стабилен для одного и того же
// блока и уникален для разных составов блоков.
export function computePublicationContentHash(input: PublishInput): string {
  const hash = createHash("sha256")
    .update(publicationPayload(input))
    .digest("hex");
  return `0x${hash}`;
}

// Формирование сертификата публикации: постоянная публичная ссылка на файл,
// время публикации, статус «Опубликован в сеть» и хеш содержимого. Время
// публикации можно передать явно (например, releasedAt), чтобы сертификат был
// детерминирован для ранее выпущенных блоков.
export function buildPublicationCertificate(
  input: PublishInput,
  options: { publishedAt?: string } = {}
): PublicationCertificate {
  return {
    url: publicBlockPath(input.number),
    publishedAt: options.publishedAt ?? new Date().toISOString(),
    status: "published",
    contentHash: computePublicationContentHash(input),
  };
}
