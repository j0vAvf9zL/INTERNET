// Генерация настоящих данных блока.
// Файл-блок размером 10 ГБ не хранится на диске: его байты стримятся при
// скачивании. В начале файла идёт реальный контент из Интернет-архива
// (сайты, новости, файлы) с манифестом состава, остаток добивается
// детерминированными данными до полного размера 10 ГБ.

import {
  blockContentItems,
  resolveArchiveItemBytes,
  type ArchiveContentItem,
  type BlockContent,
} from "./archive";

export const BLOCK_SIZE_BYTES = 10_000_000_000;
export const BLOCK_SIZE_GB = 10;
export const TARGET_BLOCK_COUNT = 1_000_000_000_000;
// Время «генерации» блока: сразу после выпуска блок считается готовящимся,
// спустя это время он становится готовым к скачиванию.
export const BLOCK_GENERATION_MS = 3_000;
// Время «подготовки» блока к майнеру: после запуска подготовки блок
// находится в статусе подготовки, спустя это время становится подготовленным
// и доступным для передачи внешнему майнеру (web-block-miner).
export const MINING_PREPARATION_MS = 4_000;

const CHUNK_SIZE = 4 * 1024 * 1024;
const HEADER_PREFIX = "BLOCKS-INTERNET-BLOCK-V1\n";

function splitmix32(a: number): () => number {
  return function () {
    a |= 0;
    a = (a + 0x9e3779b9) | 0;
    let t = a ^ (a >>> 16);
    t = Math.imul(t, 0x21f0aaad);
    t = t ^ (t >>> 15);
    t = Math.imul(t, 0x735a2d97);
    return (t = t ^ (t >>> 15)) >>> 0;
  };
}

export function generateBlockChunk(
  blockNumber: number,
  chunkIndex: number,
  size: number
): Buffer {
  const buffer = Buffer.allocUnsafe(size);
  const seed = (blockNumber ^ Math.imul(chunkIndex + 1, 0x85ebca6b)) >>> 0;
  const rand = splitmix32(seed);
  for (let offset = 0; offset < size; offset += 4) {
    buffer.writeUInt32BE(rand(), offset);
  }
  return buffer;
}

interface ResolvedContentItem {
  item: ArchiveContentItem;
  bytes: Buffer | null;
  length: number;
}

function buildManifestBuffer(
  blockNumber: number,
  sizeBytes: number,
  resolved: ResolvedContentItem[]
): Buffer {
  const items = resolved.map(({ item, bytes }) => ({
    kind: item.kind,
    title: item.title,
    url: item.url,
    byteLength: bytes?.length ?? item.byteLength,
    sha1: item.sha1,
    available: bytes !== null,
  }));

  const manifest = {
    format: "blocks-internet-block/v1",
    block: blockNumber,
    sizeBytes,
    items,
  };

  return Buffer.from(
    `${HEADER_PREFIX}${JSON.stringify(manifest, null, 2)}\n`,
    "utf8"
  );
}

export async function createBlockDataStream(
  blockNumber: number,
  sizeBytes: number = BLOCK_SIZE_BYTES,
  content: BlockContent | undefined = undefined
): Promise<ReadableStream<Uint8Array>> {
  const items = content ? blockContentItems(content) : [];
  const resolved: ResolvedContentItem[] = await Promise.all(
    items.map(async (item) => {
      const bytes = await resolveArchiveItemBytes(item);
      return { item, bytes, length: bytes?.length ?? item.byteLength };
    })
  );

  const header = buildManifestBuffer(blockNumber, sizeBytes, resolved);
  const contentBytesTotal = resolved.reduce(
    (sum, part) => sum + part.length,
    0
  );
  const fillerBytes = Math.max(
    0,
    sizeBytes - header.length - contentBytesTotal
  );

  let headerSent = false;
  let itemIndex = 0;
  let itemOffset = 0;
  let fillerChunkIndex = 0;
  let fillerSent = 0;

  return new ReadableStream<Uint8Array>({
    pull(controller) {
      if (!headerSent) {
        controller.enqueue(header);
        headerSent = true;
        return;
      }

      if (itemIndex < resolved.length) {
        const part = resolved[itemIndex];
        const remaining = part.length - itemOffset;
        if (remaining <= 0) {
          itemIndex++;
          itemOffset = 0;
          return;
        }
        if (part.bytes) {
          const size = Math.min(CHUNK_SIZE, remaining);
          controller.enqueue(
            part.bytes.subarray(itemOffset, itemOffset + size)
          );
          itemOffset += size;
        } else {
          const size = Math.min(CHUNK_SIZE, remaining);
          controller.enqueue(
            generateBlockChunk(blockNumber, fillerChunkIndex++, size)
          );
          itemOffset += size;
        }
        return;
      }

      const remainingFiller = fillerBytes - fillerSent;
      if (remainingFiller <= 0) {
        controller.close();
        return;
      }
      const size = Math.min(CHUNK_SIZE, remainingFiller);
      controller.enqueue(
        generateBlockChunk(blockNumber, fillerChunkIndex++, size)
      );
      fillerSent += size;
    },
  });
}
