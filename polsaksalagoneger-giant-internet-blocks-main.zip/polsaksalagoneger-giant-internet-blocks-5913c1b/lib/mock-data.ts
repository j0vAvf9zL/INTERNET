// Мок-данные для статического режима (без БД)
// Используются когда USE_DATABASE=false или БД недоступна

import {
  Service,
  BlockRecord,
  BlockStats,
  FactoryState,
  MinerLogEntry,
  MinerState,
  MiningResult,
} from "./models";
import {
  BLOCK_SIZE_BYTES,
  BLOCK_SIZE_GB,
  TARGET_BLOCK_COUNT,
} from "./block-file";
import { MINING_DIFFICULTY } from "./miner";
import {
  DEFAULT_FACTORY_LEVEL,
  MAX_FACTORY_LEVEL,
  blocksPerSecondForLevel,
  upgradePriceForLevel,
} from "./factory";
import type { ArchiveContentItem, BlockContent } from "./archive";
import { buildTokenCertificate, type TokenCertificate } from "./token";
import {
  buildPublicationCertificate,
  type PublicationCertificate,
} from "./publication";

export const mockServices: Service[] = [
  {
    id: "mock-service-1",
    name: "API Gateway",
    description: "Шлюз для микросервисной архитектуры",
    status: "active",
    url: "https://api.example.com",
    createdAt: new Date("2024-01-15").toISOString(),
    updatedAt: new Date("2024-01-15").toISOString(),
  },
  {
    id: "mock-service-2",
    name: "Auth Service",
    description: "Сервис аутентификации и авторизации",
    status: "active",
    url: "https://auth.example.com",
    createdAt: new Date("2024-02-01").toISOString(),
    updatedAt: new Date("2024-02-01").toISOString(),
  },
  {
    id: "mock-service-3",
    name: "ML Pipeline",
    description: "Пайплайн для обработки данных с AI",
    status: "deploying",
    url: undefined,
    createdAt: new Date("2024-03-10").toISOString(),
    updatedAt: new Date("2024-03-10").toISOString(),
  },
];

export const mockBlockStats: BlockStats = {
  released: 42_737_615,
  target: TARGET_BLOCK_COUNT,
  blockSizeGb: BLOCK_SIZE_GB,
  totalBytes: 42_737_615 * BLOCK_SIZE_BYTES,
};

export const mockFactoryState: FactoryState = {
  level: DEFAULT_FACTORY_LEVEL,
  blocksPerSecond: blocksPerSecondForLevel(DEFAULT_FACTORY_LEVEL),
  coins: 2_500_000,
  totalFactoryBlocks: 3,
  upgradePrice: upgradePriceForLevel(DEFAULT_FACTORY_LEVEL),
  maxLevel: MAX_FACTORY_LEVEL,
  startedAt: new Date("2024-01-15").toISOString(),
  updatedAt: new Date("2024-01-15").toISOString(),
};

function siteItem(
  title: string,
  url: string,
  byteLength: number
): ArchiveContentItem {
  return { kind: "site", title, url, byteLength, sha1: "mock-sha1-site" };
}

function newsItem(
  title: string,
  url: string,
  byteLength: number
): ArchiveContentItem {
  return { kind: "news", title, url, byteLength, sha1: "mock-sha1-news" };
}

function fileItem(
  title: string,
  url: string,
  byteLength: number
): ArchiveContentItem {
  return { kind: "file", title, url, byteLength, sha1: "mock-sha1-file" };
}

function mockContent(
  siteCount: number,
  newsCount: number,
  fileCount: number
): BlockContent {
  return {
    sites: [
      siteItem(
        "Wikipedia — главная страница",
        "https://web.archive.org/web/20240601000000id_/https://www.wikipedia.org/",
        22_501
      ),
      siteItem(
        "Project Gutenberg — главная страница",
        "https://web.archive.org/web/20231215000000id_/http://www.gutenberg.org/",
        21_249
      ),
    ].slice(0, siteCount),
    news: [
      newsItem(
        "BBC News — лента новостей",
        "https://web.archive.org/web/20240601000000id_/https://www.bbc.com/news",
        41_526
      ),
      newsItem(
        "DW — английская редакция",
        "https://web.archive.org/web/20240110000000id_/https://www.dw.com/en/",
        62_039
      ),
    ].slice(0, newsCount),
    files: [
      fileItem(
        "Иллюстрация «Алиса в Стране чудес» (gutenberg)",
        "https://archive.org/download/gutenberg/alice.JPG",
        9_160
      ),
      fileItem(
        "Метаданные коллекции Gutenberg (gutenberg_meta.xml)",
        "https://archive.org/download/gutenberg/gutenberg_meta.xml",
        2_940
      ),
    ].slice(0, fileCount),
  };
}

function mockToken(number: number, content?: BlockContent): TokenCertificate {
  return buildTokenCertificate({
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    fileName: `block-${number}.bin`,
    content,
  });
}

function mockPublication(
  number: number,
  content?: BlockContent
): PublicationCertificate {
  return buildPublicationCertificate({
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    fileName: `block-${number}.bin`,
    content,
  });
}

function mockBlock(
  number: number,
  minutesAgo: number,
  generatingMs = 0,
  content?: BlockContent,
  mining?: "prepared" | "preparing" | "mined",
  withToken = true
): BlockRecord {
  const releasedAt = new Date(Date.now() - minutesAgo * 60_000).toISOString();
  const readyAt = new Date(Date.parse(releasedAt) + generatingMs).toISOString();
  const isGenerating = generatingMs > 0;
  const prepared = mining === "prepared";
  const preparing = mining === "preparing";
  const mined = mining === "mined";
  const prepareStartedAt =
    prepared || preparing || mined ? releasedAt : undefined;
  const preparedAt =
    prepared || mined
      ? new Date(Date.parse(releasedAt) + 10_000).toISOString()
      : undefined;
  const minedAt = mined
    ? new Date(Date.parse(releasedAt) + 60_000).toISOString()
    : undefined;

  let miningStatus: BlockRecord["miningStatus"] = isGenerating
    ? "not_ready"
    : "ready";
  if (preparing) miningStatus = "preparing";
  if (prepared) miningStatus = "prepared";
  if (mined) miningStatus = "mined";

  return {
    id: `mock-block-${number}`,
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    sizeGb: BLOCK_SIZE_GB,
    releasedAt,
    readyAt,
    status: isGenerating ? "generating" : "ready",
    fileName: `block-${number}.bin`,
    source: "factory",
    content,
    miningStatus,
    prepareStartedAt,
    preparedAt,
    minedAt,
    minedHash: mined ? "0000c4f1a9b82e7d6c5a4b3f2e1d0c9b8a7f6e5d" : undefined,
    minedNonce: mined ? 98_123 : undefined,
    minedDurationMs: mined ? 4_219 : undefined,
    token: withToken ? mockToken(number, content) : undefined,
    publication: mockPublication(number, content),
  };
}

export const mockBlocks: BlockRecord[] = [
  mockBlock(42_737_615, 5, 120_000, mockContent(3, 2, 2)),
  mockBlock(
    42_737_614,
    10,
    undefined,
    mockContent(3, 2, 1),
    "preparing",
    false
  ),
  mockBlock(42_737_613, 15, undefined, mockContent(2, 2, 2), "mined"),
  mockBlock(42_737_612, 20, undefined, mockContent(2, 1, 2), "mined", false),
  mockBlock(42_737_611, 25, undefined, mockContent(3, 2, 2), "prepared"),
  mockBlock(42_737_610, 30, undefined, mockContent(3, 1, 1)),
];

export const mockMinerState: MinerState = {
  status: "idle",
  currentBlockNumber: null,
  processedBlocks: 2,
  startedAt: new Date(Date.now() - 30 * 60_000).toISOString(),
  updatedAt: new Date(Date.now() - 5 * 60_000).toISOString(),
};

export const mockMiningResults: MiningResult[] = [
  {
    blockNumber: 42_737_613,
    status: "done",
    startedAt: new Date(Date.now() - 25 * 60_000).toISOString(),
    completedAt: new Date(Date.now() - 24 * 60_000).toISOString(),
    hash: "0000c4f1a9b82e7d6c5a4b3f2e1d0c9b8a7f6e5d",
    nonce: 98_123,
    difficulty: MINING_DIFFICULTY,
    durationMs: 4_219,
  },
  {
    blockNumber: 42_737_612,
    status: "done",
    startedAt: new Date(Date.now() - 40 * 60_000).toISOString(),
    completedAt: new Date(Date.now() - 39 * 60_000).toISOString(),
    hash: "00007be2c5d1a8f3e6b90c4d7a1f2e8b5c0d9a6e3",
    nonce: 152_340,
    difficulty: MINING_DIFFICULTY,
    durationMs: 6_387,
  },
];

export const mockMinerLogs: MinerLogEntry[] = [
  {
    id: "mock-log-1",
    time: new Date(Date.now() - 35 * 60_000).toISOString(),
    text: "МАЙНЕР: МОДУЛЬ ЗАГРУЖЕН (web-block-miner)",
    tone: "info",
  },
  {
    id: "mock-log-2",
    time: new Date(Date.now() - 34 * 60_000).toISOString(),
    text: "МАЙНЕР: НАЧАТА ДОБЫЧА БЛОКА #042737612 (сложность 0000…)",
    tone: "info",
  },
  {
    id: "mock-log-3",
    time: new Date(Date.now() - 33 * 60_000).toISOString(),
    text: "МАЙНЕР: БЛОК #042737612 ДОБЫТ [00007be2…] NONCE 152340 — OK",
    tone: "ok",
  },
  {
    id: "mock-log-4",
    time: new Date(Date.now() - 26 * 60_000).toISOString(),
    text: "МАЙНЕР: НАЧАТА ДОБЫЧА БЛОКА #042737613 (сложность 0000…)",
    tone: "info",
  },
  {
    id: "mock-log-5",
    time: new Date(Date.now() - 24 * 60_000).toISOString(),
    text: "МАЙНЕР: БЛОК #042737613 ДОБЫТ [0000c4f1…] NONCE 98123 — OK",
    tone: "ok",
  },
];
