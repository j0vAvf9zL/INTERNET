import { isDatabaseAvailable } from "./db";
import {
  ensureCatalogLoaded,
  getCachedCatalog,
  refreshCatalogInBackground,
} from "./archive";
import { getFactoryState, produceFactoryBlock } from "./models";

const ENGINE_KEY = "__factoryEngineV1";

interface EngineHandle {
  timer: ReturnType<typeof setTimeout> | null;
  running: boolean;
}

function engineHandle(): EngineHandle {
  const globalRef = globalThis as Record<string, unknown>;
  if (!globalRef[ENGINE_KEY]) {
    globalRef[ENGINE_KEY] = { timer: null, running: false };
  }
  return globalRef[ENGINE_KEY] as EngineHandle;
}

export async function ensureFactoryEngineStarted(): Promise<void> {
  if (!(await isDatabaseAvailable())) return;

  const handle = engineHandle();
  if (handle.timer) return;

  const run = async () => {
    if (handle.running) {
      handle.timer = setTimeout(run, 100);
      return;
    }

    handle.running = true;
    try {
      if (!getCachedCatalog()) {
        await ensureCatalogLoaded();
      } else {
        refreshCatalogInBackground();
      }
      const state = await getFactoryState();
      const intervalMs = Math.max(Math.round(1000 / state.blocksPerSecond), 15);
      handle.timer = setTimeout(run, intervalMs);
      await produceFactoryBlock();
    } catch (error) {
      console.error("Ошибка цикла автоматической фабрики:", error);
      handle.timer = setTimeout(run, 3000);
    } finally {
      handle.running = false;
    }
  };

  handle.timer = setTimeout(run, 1000);
}
