// Клиент открытых источников Интернет-архива.
// Блоки наполняются реальными данными из Интернет-архива: снимками сайтов
// (Wayback Machine), новостными страницами и файлами с archive.org.
//
// Чтобы автоматическая фабрика (до 16 блоков/с) не дёргала архив на каждый
// выпуск, байты реального контента кэшируются в памяти процесса и периодически
// обновляются. Ручной выпуск дополнительно принудительно освежает каталог перед
// составлением блока. Состав конкретного блока детерминированно выбирается из
// каталога по номеру блока.

import { createHash } from "node:crypto";

export type ArchiveKind = "site" | "news" | "file";

export interface ArchiveContentItem {
  kind: ArchiveKind;
  title: string;
  url: string;
  byteLength: number;
  sha1?: string;
}

export interface BlockContent {
  sites: ArchiveContentItem[];
  news: ArchiveContentItem[];
  files: ArchiveContentItem[];
}

export function blockContentItems(content: BlockContent): ArchiveContentItem[] {
  return [...content.sites, ...content.news, ...content.files];
}

interface CatalogEntry {
  kind: ArchiveKind;
  title: string;
  url: string;
}

const SITES: Omit<CatalogEntry, "kind">[] = [
  {
    title: "Wikipedia — главная страница",
    url: "https://web.archive.org/web/20240601000000id_/https://www.wikipedia.org/",
  },
  {
    title: "Project Gutenberg — главная страница",
    url: "https://web.archive.org/web/20231215000000id_/http://www.gutenberg.org/",
  },
  {
    title: "Internet Archive — главная страница",
    url: "https://web.archive.org/web/20240101000000id_/https://archive.org/",
  },
  {
    title: "NASA — главная страница",
    url: "https://web.archive.org/web/20231201000000id_/https://www.nasa.gov/",
  },
  {
    title: "Open Library — главная страница",
    url: "https://web.archive.org/web/20240201000000id_/https://openlibrary.org/",
  },
  {
    title: "Mozilla — главная страница",
    url: "https://web.archive.org/web/20240120000000id_/https://www.mozilla.org/en-US/",
  },
  {
    title: "example.com (RFC 2606)",
    url: "https://web.archive.org/web/20240101000000id_/http://example.com/",
  },
];

const NEWS: Omit<CatalogEntry, "kind">[] = [
  {
    title: "BBC News — лента новостей",
    url: "https://web.archive.org/web/20240601000000id_/https://www.bbc.com/news",
  },
  {
    title: "The Guardian — международная лента",
    url: "https://web.archive.org/web/20240201000000id_/https://www.theguardian.com/international",
  },
  {
    title: "DW — английская редакция",
    url: "https://web.archive.org/web/20240110000000id_/https://www.dw.com/en/",
  },
  {
    title: "NPR — раздел новостей",
    url: "https://web.archive.org/web/20240101000000id_/https://www.npr.org/sections/news/",
  },
  {
    title: "Al Jazeera — главная страница",
    url: "https://web.archive.org/web/20240101000000id_/https://www.aljazeera.com/",
  },
  {
    title: "CNN — международная версия",
    url: "https://web.archive.org/web/20240115000000id_/https://edition.cnn.com/",
  },
];

const FILES: Omit<CatalogEntry, "kind">[] = [
  {
    title: "Иллюстрация «Алиса в Стране чудес» (gutenberg)",
    url: "https://archive.org/download/gutenberg/alice.JPG",
  },
  {
    title: "Метаданные коллекции Gutenberg (gutenberg_meta.xml)",
    url: "https://archive.org/download/gutenberg/gutenberg_meta.xml",
  },
  {
    title: "The Deaf-Mutes' Journal, 1929 (полный текст)",
    url: "https://archive.org/download/gu_deafmutesjo19290418/gu_deafmutesjo19290418_djvu.txt",
  },
  {
    title: "Big Rock Candy Mountain (полный текст)",
    url: "https://archive.org/download/bigrockcandymoun00unse/bigrockcandymoun00unse_djvu.txt",
  },
  {
    title: "Логотип LibriVox (librivoxlogo.jpg)",
    url: "https://archive.org/download/librivoxaudio/librivoxlogo.jpg",
  },
  {
    title: "Обложка Amazing Stories (astounding3.jpg)",
    url: "https://archive.org/download/librivoxaudio/astounding3.jpg",
  },
  {
    title: "Метаданные LibriVox (librivoxaudio_meta.xml)",
    url: "https://archive.org/download/librivoxaudio/librivoxaudio_meta.xml",
  },
];

// Максимальный размер одного элемента реального контента (байт).
export const ITEM_BYTE_CAP = 128 * 1024;
// Сколько элементов каждого типа попадает в один блок.
export const CONTENT_COUNTS = { sites: 3, news: 2, files: 2 } as const;
// Как часто перечитывать каталог из архива.
export const CATALOG_TTL_MS = 10 * 60_000;

export interface ArchiveContentItemWithBytes extends ArchiveContentItem {
  bytes: Buffer;
}

interface Catalog {
  sites: ArchiveContentItemWithBytes[];
  news: ArchiveContentItemWithBytes[];
  files: ArchiveContentItemWithBytes[];
}

function totalItems(catalog: Catalog): number {
  return catalog.sites.length + catalog.news.length + catalog.files.length;
}

function allCatalogItems(catalog: Catalog): ArchiveContentItemWithBytes[] {
  return [...catalog.sites, ...catalog.news, ...catalog.files];
}

let catalogCache: Catalog | null = null;
let catalogLoadedAt = 0;
let catalogFetchPromise: Promise<Catalog> | null = null;

function sha1Hex(buffer: Buffer): string {
  return createHash("sha1").update(buffer).digest("hex");
}

function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pickShuffled<T>(
  source: T[],
  count: number,
  random: () => number
): T[] {
  const copy = [...source];
  const picked: T[] = [];
  const size = Math.min(count, copy.length);
  for (let i = 0; i < size; i++) {
    const j = i + Math.floor(random() * (copy.length - i));
    [copy[i], copy[j]] = [copy[j], copy[i]];
    picked.push(copy[i]);
  }
  return picked;
}

export async function fetchArchiveUrlBytes(
  url: string,
  capBytes: number = ITEM_BYTE_CAP
): Promise<Buffer | null> {
  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "blocks-internet/1.0 (block generator; archive.org)",
        Accept: "*/*",
      },
      signal: AbortSignal.timeout(8_000),
      redirect: "follow",
    });
    if (!response.ok || !response.body) return null;

    const reader = response.body.getReader();
    const chunks: Uint8Array[] = [];
    let total = 0;
    for (;;) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      total += value.length;
      if (total >= capBytes) break;
    }
    await reader.cancel().catch(() => void 0);

    const combined = Buffer.concat(chunks.map((chunk) => Buffer.from(chunk)));
    return combined.subarray(0, capBytes);
  } catch {
    return null;
  }
}

async function fetchCatalog(): Promise<Catalog> {
  if (catalogFetchPromise) return catalogFetchPromise;

  catalogFetchPromise = (async () => {
    const entries: CatalogEntry[] = [
      ...SITES.map((entry) => ({ kind: "site" as const, ...entry })),
      ...NEWS.map((entry) => ({ kind: "news" as const, ...entry })),
      ...FILES.map((entry) => ({ kind: "file" as const, ...entry })),
    ];

    const settled = await Promise.all(
      entries.map(
        async (entry): Promise<ArchiveContentItemWithBytes | null> => {
          const bytes = await fetchArchiveUrlBytes(entry.url);
          if (!bytes || bytes.length === 0) return null;
          return {
            kind: entry.kind,
            title: entry.title,
            url: entry.url,
            byteLength: bytes.length,
            sha1: sha1Hex(bytes),
            bytes,
          };
        }
      )
    );

    // Сливаем со старым кэшем: если какой-то ресурс не скачался в этот раз,
    // оставляем его прежние байты, чтобы каталог не «ужимался».
    const freshByUrl = new Map<string, ArchiveContentItemWithBytes>();
    for (const item of settled) {
      if (item) freshByUrl.set(item.url, item);
    }
    const previousByUrl = new Map<string, ArchiveContentItemWithBytes>();
    if (catalogCache) {
      for (const item of allCatalogItems(catalogCache)) {
        previousByUrl.set(item.url, item);
      }
    }

    const items: ArchiveContentItemWithBytes[] = [];
    for (const entry of entries) {
      const freshItem = freshByUrl.get(entry.url);
      if (freshItem) {
        items.push(freshItem);
      } else {
        const previous = previousByUrl.get(entry.url);
        if (previous) items.push(previous);
      }
    }

    const catalog: Catalog = {
      sites: items.filter((item) => item.kind === "site"),
      news: items.filter((item) => item.kind === "news"),
      files: items.filter((item) => item.kind === "file"),
    };

    if (items.length > 0) {
      catalogCache = catalog;
      catalogLoadedAt = Date.now();
    }
    return catalog;
  })();

  try {
    return await catalogFetchPromise;
  } finally {
    catalogFetchPromise = null;
  }
}

function isCatalogStale(): boolean {
  return !catalogCache || Date.now() - catalogLoadedAt >= CATALOG_TTL_MS;
}

export function peekCatalogItems(): ArchiveContentItemWithBytes[] | null {
  if (!catalogCache) return null;
  return [...catalogCache.sites, ...catalogCache.news, ...catalogCache.files];
}

export function getCachedCatalog(): Catalog | null {
  return catalogCache;
}

export function catalogLoaded(): boolean {
  return catalogCache !== null;
}

// Ждет загрузку каталога. Если данных нет или они устарели — перечитывает;
// при force=true перечитывает всегда (для ручного выпуска блока).
export async function ensureCatalogLoaded(force = false): Promise<Catalog> {
  const refreshNeeded =
    !catalogCache || isCatalogStale() || force || !catalogLoaded();
  if (!refreshNeeded) return catalogCache as Catalog;

  const fetched = await fetchCatalog();
  if (fetched && totalItems(fetched) > 0) return fetched;
  if (catalogCache) return catalogCache;
  return fetched;
}

// Фоновое обновление каталога без ожидания (для фабрики).
export function refreshCatalogInBackground(): void {
  if (!isCatalogStale()) return;
  void fetchCatalog().catch(() => void 0);
}

// Байты элемента: сначала ищем в кэше каталога, затем пробуем скачать напрямую.
export async function resolveArchiveItemBytes(
  item: ArchiveContentItem
): Promise<Buffer | null> {
  const cached = peekCatalogItems()?.find(
    (candidate) => candidate.url === item.url
  );
  if (cached) return cached.bytes;
  return fetchArchiveUrlBytes(item.url, item.byteLength || ITEM_BYTE_CAP);
}

function stripBytes(item: ArchiveContentItemWithBytes): ArchiveContentItem {
  return {
    kind: item.kind,
    title: item.title,
    url: item.url,
    byteLength: item.byteLength,
    sha1: item.sha1,
  };
}

// Детерминированный подбор состава блока из каталога по номеру блока.
export function selectBlockContent(
  catalog: Catalog,
  blockNumber: number
): BlockContent {
  const random = mulberry32(blockNumber);
  return {
    sites: pickShuffled(catalog.sites, CONTENT_COUNTS.sites, random).map(
      stripBytes
    ),
    news: pickShuffled(catalog.news, CONTENT_COUNTS.news, random).map(
      stripBytes
    ),
    files: pickShuffled(catalog.files, CONTENT_COUNTS.files, random).map(
      stripBytes
    ),
  };
}
