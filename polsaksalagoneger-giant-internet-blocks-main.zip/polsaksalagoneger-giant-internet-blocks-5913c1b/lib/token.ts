// Токенизация блоков в Ethereum — встроенная.
// Сервис сам формирует токен-сертификаты: уникальный номер токена, хеш
// содержимого блока, адрес контракта, хеш транзакции и ссылку на просмотр
// в проводнике. Внешний кошелёк не подключается.

import { createHash } from "node:crypto";
import { blockContentItems, type BlockContent } from "./archive";

// Адрес контракта токена (демонстрационный, формат Ethereum EIP-55).
export const TOKEN_CONTRACT_ADDRESS =
  "0xB10c571CE57e57EA11b102C26F9fdaFF6de5AF23";
// Проводник для просмотра токенов.
export const TOKEN_EXPLORER_URL = "https://etherscan.io";

export type TokenStatus = "issued";

export interface TokenCertificate {
  tokenId: number;
  contentHash: string;
  contractAddress: string;
  txHash: string;
  explorerUrl: string;
  issuedAt: string;
  status: TokenStatus;
}

export interface TokenizeInput {
  number: number;
  sizeBytes: number;
  fileName: string;
  content?: BlockContent;
}

function contentManifestPayload(input: TokenizeInput): string {
  const items = input.content
    ? blockContentItems(input.content)
        .map((item) => ({
          kind: item.kind,
          title: item.title,
          url: item.url,
          byteLength: item.byteLength,
          sha1: item.sha1 ?? "",
        }))
        .sort((a, b) => a.url.localeCompare(b.url))
    : [];
  return JSON.stringify({
    format: "blocks-internet-token/v1",
    number: input.number,
    sizeBytes: input.sizeBytes,
    fileName: input.fileName,
    items,
  });
}

// Детерминированный хеш содержимого блока: стабилен для одного и того же
// блока и уникален для разных составов блоков.
export function computeBlockContentHash(input: TokenizeInput): string {
  const hash = createHash("sha256")
    .update(contentManifestPayload(input))
    .digest("hex");
  return `0x${hash}`;
}

// Детерминированный хеш транзакции выпуска токена в сеть.
export function computeTokenTxHash(
  number: number,
  contentHash: string
): string {
  const hash = createHash("sha256")
    .update(`blocks-internet-ethereum-tx:${number}:${contentHash}`)
    .digest("hex");
  return `0x${hash}`;
}

// Формирование токен-сертификата: уникальный номер токена, хеш содержимого
// блока, адрес контракта, хеш транзакции и ссылка на проводник.
export function buildTokenCertificate(input: TokenizeInput): TokenCertificate {
  const contentHash = computeBlockContentHash(input);
  const txHash = computeTokenTxHash(input.number, contentHash);
  return {
    tokenId: input.number,
    contentHash,
    contractAddress: TOKEN_CONTRACT_ADDRESS,
    txHash,
    explorerUrl: `${TOKEN_EXPLORER_URL}/token/${TOKEN_CONTRACT_ADDRESS}?a=${input.number}`,
    issuedAt: new Date().toISOString(),
    status: "issued",
  };
}
