// Серверный движок майнера блоков. Внешний проект web-block-miner
// обрабатывает подготовленные блоки; в этом приложении запускается его
// «пульт»: пока статус майнера running, движок берёт подготовленные блоки по
// очереди, добывает их (подбор nonce/hash) и сохраняет результат.

import { isDatabaseAvailable } from "./db";
import { getMinerState, mineNextBlock } from "./models";

const ENGINE_KEY = "__minerEngineV1";

interface EngineHandle {
  timer: ReturnType<typeof setTimeout> | null;
  running: boolean;
}

function engineHandle(): EngineHandle {
  const globalRef = globalThis as Record<string, unknown>;
  if (!globalRef[ENGINE_KEY]) {
    globalRef[ENGINE_KEY] = { timer: null, running: false };
  }
  return globalRef[ENGINE_KEY] as EngineHandle;
}

export async function ensureMinerEngineStarted(): Promise<void> {
  if (!(await isDatabaseAvailable())) return;

  const handle = engineHandle();
  if (handle.timer) return;

  const run = async () => {
    if (handle.running) {
      handle.timer = setTimeout(run, 100);
      return;
    }

    handle.running = true;
    try {
      if (!(await isDatabaseAvailable())) return;
      const state = await getMinerState();
      if (state.status !== "running") {
        handle.timer = null;
        return;
      }
      const mined = await mineNextBlock();
      handle.timer = setTimeout(run, mined ? 150 : 800);
    } catch (error) {
      console.error("Ошибка цикла майнера:", error);
      handle.timer = setTimeout(run, 3000);
    } finally {
      handle.running = false;
    }
  };

  handle.timer = setTimeout(run, 400);
}
