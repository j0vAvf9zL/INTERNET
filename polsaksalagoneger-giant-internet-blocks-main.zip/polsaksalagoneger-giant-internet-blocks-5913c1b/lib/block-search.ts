// Поиск блоков по истории и содержимому.
// Чистые функции фильтрации, общие для DynamoDB-пути и mock-режима.

import type { BlockRecord, BlockSource } from "./models";
import type { ArchiveContentItem, ArchiveKind } from "./archive";

export type ContentTypeFilter = ArchiveKind | "all";
export type SourceFilter = BlockSource | "all";

export interface BlockSearchQuery {
  q?: string;
  type?: ContentTypeFilter;
  source?: SourceFilter;
  date?: string;
}

export const CONTENT_KINDS: ArchiveKind[] = ["site", "news", "file"];

function contentItemsOfKind(
  block: BlockRecord,
  kind: ArchiveKind
): ArchiveContentItem[] {
  const content = block.content;
  if (!content) return [];
  if (kind === "site") return content.sites;
  if (kind === "news") return content.news;
  return content.files;
}

function hasKind(block: BlockRecord, kind: ArchiveKind): boolean {
  return contentItemsOfKind(block, kind).length > 0;
}

// Совпадает ли блок с поисковым запросом.
// Фильтры источника и даты — строгие (AND), текстовый запрос ищет по номеру,
// дате выпуска и элементам состава (заголовкам/URL из Интернет-архива).
// Когда текста нет, фильтр типа работает как «по составу»: показываются блоки,
// в которых есть контент выбранного типа (сайты/новости/файлы).
export function matchesBlockQuery(
  block: BlockRecord,
  query: BlockSearchQuery
): boolean {
  const q = (query.q ?? "").trim().toLowerCase();
  const type = query.type ?? "all";
  const source = query.source ?? "all";
  const date = (query.date ?? "").trim();

  if (source !== "all" && block.source !== source) return false;

  if (date && block.releasedAt.slice(0, 10) !== date) return false;

  const kinds: ArchiveKind[] = type === "all" ? CONTENT_KINDS : [type];

  if (q) {
    if (String(block.number).includes(q)) return true;
    if (block.releasedAt.toLowerCase().includes(q)) return true;
    return kinds.some((kind) =>
      contentItemsOfKind(block, kind).some(
        (item) =>
          item.title.toLowerCase().includes(q) ||
          item.url.toLowerCase().includes(q)
      )
    );
  }

  return kinds.some((kind) => hasKind(block, kind));
}

// Какие элементы состава блока соответствуют тексту запроса (для подсветки в
// результатах). Учитывает ограничение по типу контента.
export function findMatchedItems(
  block: BlockRecord,
  query: BlockSearchQuery
): ArchiveContentItem[] {
  const q = (query.q ?? "").trim().toLowerCase();
  if (!q) return [];
  const type = query.type ?? "all";
  const kinds: ArchiveKind[] = type === "all" ? CONTENT_KINDS : [type];
  return kinds.flatMap((kind) =>
    contentItemsOfKind(block, kind).filter(
      (item) =>
        item.title.toLowerCase().includes(q) ||
        item.url.toLowerCase().includes(q)
    )
  );
}
