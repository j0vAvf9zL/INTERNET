export const TERMINAL_META = {
  productName: "Блоки Интернета",
  version: "v0.1.0-pre",
  mode: "Онлайн",
};

export type LogTone = "info" | "ok" | "warn";

export interface LogLine {
  time: string;
  text: string;
  tone: LogTone;
}

export const TERMINAL_LOG: LogLine[] = [
  { time: "00:00:00", text: "ЗАПУСК ЯДРА БЛОКОГЕНЕРАТОРА...", tone: "info" },
  { time: "00:00:01", text: "ПРОВЕРКА СЕКТОРОВ НАКОПИТЕЛЯ... OK", tone: "ok" },
  {
    time: "00:00:02",
    text: "МОДУЛЬ АВТОМАТИЧЕСКОЙ ФАБРИКИ АКТИВИРОВАН",
    tone: "ok",
  },
  {
    time: "00:00:03",
    text: "СЧЁТЧИК: 42 737 615 ИЗ 1 000 000 000 000",
    tone: "info",
  },
  {
    time: "00:00:04",
    text: "ВЫПУЩЕН БЛОК #042737612 [10 ГБ] — OK",
    tone: "ok",
  },
  {
    time: "00:00:05",
    text: "ВЫПУЩЕН БЛОК #042737613 [10 ГБ] — OK",
    tone: "ok",
  },
  {
    time: "00:00:06",
    text: "ВЫПУЩЕН БЛОК #042737614 [10 ГБ] — OK",
    tone: "ok",
  },
  { time: "00:00:07", text: "ОСТАЛОСЬ ДО ЦЕЛИ: 999 957 262 385", tone: "warn" },
  {
    time: "00:00:08",
    text: "СИСТЕМА ГОТОВА К ВЫПУСКУ НАСТОЯЩИХ БЛОКОВ",
    tone: "ok",
  },
];
