import { createHash } from "node:crypto";
import type { AttributeValue } from "@aws-sdk/client-dynamodb";
import { docClient } from "./db";
import {
  GetCommand,
  PutCommand,
  DeleteCommand,
  QueryCommand,
  ScanCommand,
  UpdateCommand,
} from "@aws-sdk/lib-dynamodb";
import {
  MINING_DIFFICULTY,
  MINING_DURATION_MS,
  MINING_RESULT_LIMIT,
  MINER_LOG_LIMIT,
} from "./miner";
import { TableName, IndexName } from "./schema";
import { matchesBlockQuery, type BlockSearchQuery } from "./block-search";
import {
  BLOCK_GENERATION_MS,
  BLOCK_SIZE_BYTES,
  BLOCK_SIZE_GB,
  MINING_PREPARATION_MS,
  TARGET_BLOCK_COUNT,
} from "./block-file";
import {
  getCachedCatalog,
  ensureCatalogLoaded,
  refreshCatalogInBackground,
  selectBlockContent,
  type BlockContent,
} from "./archive";
import {
  COINS_PER_BLOCK,
  DEFAULT_FACTORY_LEVEL,
  MAX_FACTORY_LEVEL,
  blocksPerSecondForLevel,
  upgradePriceForLevel,
} from "./factory";
import { buildTokenCertificate, type TokenCertificate } from "./token";
import {
  buildPublicationCertificate,
  type PublicationCertificate,
} from "./publication";

export const INITIAL_BLOCK_COUNT = 42_737_615;

const BLOCK_PK = "block";
const COUNTER_PK = "counter";
const COUNTER_SK = "global";
const FACTORY_PK = "factory";
const FACTORY_SK = "state";
const MINER_PK = "miner";
const MINER_SK = "state";
const MINING_PK = "mining";
const MINER_LOG_PK = "miner-log";

function padBlockNumber(number: number): string {
  return String(number).padStart(15, "0");
}

export interface Service {
  id: string;
  name: string;
  description?: string;
  status: "active" | "inactive" | "deploying";
  url?: string;
  createdAt: string;
  updatedAt: string;
}

export async function getServiceById(id: string): Promise<Service | null> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
  return (result.Item as Service) ?? null;
}

export async function getServicesByStatus(status: string): Promise<Service[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.SERVICES,
      IndexName: IndexName.SERVICES_STATUS,
      KeyConditionExpression: "#status = :status",
      ExpressionAttributeNames: {
        "#status": "status",
      },
      ExpressionAttributeValues: {
        ":status": status,
      },
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function getAllServices(): Promise<Service[]> {
  const result = await docClient.send(
    new ScanCommand({
      TableName: TableName.SERVICES,
    })
  );
  return (result.Items as Service[]) ?? [];
}

export async function createService(
  data: Omit<Service, "createdAt" | "updatedAt">
): Promise<Service> {
  const now = new Date().toISOString();
  const service: Service = {
    ...data,
    createdAt: now,
    updatedAt: now,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.SERVICES,
      Item: service,
    })
  );

  return service;
}

export async function updateService(
  id: string,
  data: Partial<Pick<Service, "name" | "description" | "status" | "url">>
): Promise<Service> {
  const updateExpr = [];
  const exprValues: Record<string, unknown> = {};
  const exprNames: Record<string, string> = {};

  if (data.name !== undefined) {
    updateExpr.push("#name = :name");
    exprValues[":name"] = data.name;
    exprNames["#name"] = "name";
  }

  if (data.description !== undefined) {
    updateExpr.push("#description = :description");
    exprValues[":description"] = data.description;
    exprNames["#description"] = "description";
  }

  if (data.status !== undefined) {
    updateExpr.push("#status = :status");
    exprValues[":status"] = data.status;
    exprNames["#status"] = "status";
  }

  if (data.url !== undefined) {
    updateExpr.push("#url = :url");
    exprValues[":url"] = data.url;
    exprNames["#url"] = "url";
  }

  updateExpr.push("updatedAt = :updatedAt");
  exprValues[":updatedAt"] = new Date().toISOString();

  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.SERVICES,
      Key: { id },
      UpdateExpression: `set ${updateExpr.join(", ")}`,
      ExpressionAttributeValues: exprValues,
      ExpressionAttributeNames:
        Object.keys(exprNames).length > 0 ? exprNames : undefined,
      ReturnValues: "ALL_NEW",
    })
  );

  return result.Attributes as Service;
}

export async function deleteService(id: string): Promise<void> {
  await docClient.send(
    new DeleteCommand({
      TableName: TableName.SERVICES,
      Key: { id },
    })
  );
}

export type BlockStatus = "generating" | "ready";
// Готовность блока к майнингу:
// - not_ready — блок ещё выпускается (генерация файла не завершена);
// - ready — блок готов, его можно подготовить для майнера;
// - preparing — идёт подготовка блока для обработки майнером;
// - prepared — блок подготовлен и доступен для передачи майнеру;
// - mined — блок обработан майнером (web-block-miner), результат сохранён.
export type MiningStatus =
  | "not_ready"
  | "ready"
  | "preparing"
  | "prepared"
  | "mined";
export type BlockSource = "manual" | "factory";

export interface BlockRecord {
  id: string;
  number: number;
  sizeBytes: number;
  sizeGb: number;
  releasedAt: string;
  readyAt: string;
  status: BlockStatus;
  fileName: string;
  source: BlockSource;
  content?: BlockContent;
  miningStatus: MiningStatus;
  prepareStartedAt?: string;
  preparedAt?: string;
  minedAt?: string;
  minedHash?: string;
  minedNonce?: number;
  minedDurationMs?: number;
  // Токен-сертификат выпуска блока в сеть Ethereum. Отсутствует у блоков,
  // которые ещё не были токенизированы.
  token?: TokenCertificate;
  // Сертификат публикации блока в сеть Интернет: постоянная публичная ссылка
  // на файл и статус «Опубликован в сеть». Формируется автоматически при
  // выпуске блока; для ранее выпущенных блоков выводится детерминированно.
  publication?: PublicationCertificate;
}

export interface BlockStats {
  released: number;
  target: number;
  blockSizeGb: number;
  totalBytes: number;
}

export interface BlocksOverview {
  stats: BlockStats;
  blocks: BlockRecord[];
}

export interface FactoryState {
  level: number;
  blocksPerSecond: number;
  coins: number;
  totalFactoryBlocks: number;
  upgradePrice: number;
  maxLevel: number;
  startedAt: string;
  updatedAt: string;
}

export type MinerStatus = "idle" | "running";

export interface MinerState {
  status: MinerStatus;
  currentBlockNumber: number | null;
  processedBlocks: number;
  startedAt: string | null;
  updatedAt: string;
}

export type MiningResultStatus = "processing" | "done";

export interface MiningResult {
  blockNumber: number;
  status: MiningResultStatus;
  startedAt: string;
  completedAt?: string;
  hash?: string;
  nonce?: number;
  difficulty: string;
  durationMs?: number;
}

export interface MinerLogEntry {
  id: string;
  time: string;
  text: string;
  tone: "info" | "ok" | "warn";
}

async function ensureCounter(): Promise<void> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: COUNTER_PK, sk: COUNTER_SK },
    })
  );

  if (!result.Item) {
    await docClient.send(
      new PutCommand({
        TableName: TableName.BLOCKS,
        Item: { pk: COUNTER_PK, sk: COUNTER_SK, count: INITIAL_BLOCK_COUNT },
      })
    );
  }
}

async function nextBlockNumber(): Promise<number> {
  await ensureCounter();
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: COUNTER_PK, sk: COUNTER_SK },
      UpdateExpression: "ADD #count :one",
      ExpressionAttributeNames: { "#count": "count" },
      ExpressionAttributeValues: { ":one": 1 },
      ReturnValues: "ALL_NEW",
    })
  );
  return (result.Attributes?.count as number) ?? 0;
}

export async function getBlockStats(): Promise<BlockStats> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: COUNTER_PK, sk: COUNTER_SK },
    })
  );

  let released = result.Item?.count as number | undefined;
  if (released === undefined) {
    await ensureCounter();
    released = INITIAL_BLOCK_COUNT;
  }

  return {
    released,
    target: TARGET_BLOCK_COUNT,
    blockSizeGb: BLOCK_SIZE_GB,
    totalBytes: released * BLOCK_SIZE_BYTES,
  };
}

function blockStatus(readyAt?: string): BlockStatus {
  if (!readyAt) return "ready";
  return new Date(readyAt).getTime() <= Date.now() ? "ready" : "generating";
}

function toMiningStatus(
  item: Record<string, unknown>,
  blockReady: boolean
): MiningStatus {
  const minedAt = item.minedAt as string | undefined;
  if (minedAt) return "mined";
  const prepareStartedAt = item.prepareStartedAt as string | undefined;
  const preparedAt = item.preparedAt as string | undefined;
  if (preparedAt && new Date(preparedAt).getTime() <= Date.now()) {
    return "prepared";
  }
  if (prepareStartedAt) return "preparing";
  return blockReady ? "ready" : "not_ready";
}

function toBlockRecord(item: Record<string, unknown>): BlockRecord {
  const readyAt =
    (item.readyAt as string | undefined) ??
    (item.releasedAt as string) ??
    new Date().toISOString();
  const status = blockStatus(readyAt);
  return {
    id: item.id as string,
    number: item.number as number,
    sizeBytes: item.sizeBytes as number,
    sizeGb: item.sizeGb as number,
    releasedAt: item.releasedAt as string,
    readyAt,
    status,
    fileName: item.fileName as string,
    source: (item.source as BlockSource | undefined) ?? "manual",
    content: item.content as BlockContent | undefined,
    miningStatus: toMiningStatus(item, status === "ready"),
    prepareStartedAt: item.prepareStartedAt as string | undefined,
    preparedAt: item.preparedAt as string | undefined,
    minedAt: item.minedAt as string | undefined,
    minedHash: item.minedHash as string | undefined,
    minedNonce: item.minedNonce as number | undefined,
    minedDurationMs: item.minedDurationMs as number | undefined,
    token: item.token as TokenCertificate | undefined,
    publication:
      (item.publication as PublicationCertificate | undefined) ??
      buildPublicationCertificate(
        {
          number: item.number as number,
          sizeBytes: item.sizeBytes as number,
          fileName: item.fileName as string,
          content: item.content as BlockContent | undefined,
        },
        { publishedAt: (item.releasedAt as string) ?? new Date().toISOString() }
      ),
  };
}

async function composeBlockContent(
  source: BlockSource,
  blockNumber: number
): Promise<BlockContent> {
  if (source === "factory") {
    let catalog = getCachedCatalog();
    if (!catalog) catalog = await ensureCatalogLoaded();
    else refreshCatalogInBackground();
    return selectBlockContent(catalog, blockNumber);
  }

  const catalog = await ensureCatalogLoaded(true);
  return selectBlockContent(catalog, blockNumber);
}

export async function createBlock(
  source: BlockSource = "manual"
): Promise<BlockRecord> {
  const number = await nextBlockNumber();
  const releasedAt = new Date().toISOString();
  const readyAt = new Date(Date.now() + BLOCK_GENERATION_MS).toISOString();
  const content = await composeBlockContent(source, number);
  const fileName = `block-${number}.bin`;
  // Встроенная токенизация: при выпуске блока сразу формируется
  // токен-сертификат для сети Ethereum.
  const token = buildTokenCertificate({
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    fileName,
    content,
  });
  // Встроенная публикация в сеть Интернет: при выпуске блок автоматически
  // получает постоянную публичную ссылку на файл и статус «Опубликован в сеть».
  const publication = buildPublicationCertificate({
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    fileName,
    content,
  });
  const block: BlockRecord = {
    id: crypto.randomUUID(),
    number,
    sizeBytes: BLOCK_SIZE_BYTES,
    sizeGb: BLOCK_SIZE_GB,
    releasedAt,
    readyAt,
    status: "generating",
    fileName,
    source,
    content,
    miningStatus: "not_ready",
    token,
    publication,
  };

  await docClient.send(
    new PutCommand({
      TableName: TableName.BLOCKS,
      Item: {
        pk: BLOCK_PK,
        sk: padBlockNumber(number),
        ...block,
      },
    })
  );

  await creditCoins(COINS_PER_BLOCK);

  return block;
}

export async function getBlockByNumber(
  number: number
): Promise<BlockRecord | null> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk AND sk = :sk",
      ExpressionAttributeValues: {
        ":pk": BLOCK_PK,
        ":sk": padBlockNumber(number),
      },
      Limit: 1,
    })
  );
  const item = result.Items?.[0];
  if (!item) return null;
  return toBlockRecord(item as Record<string, unknown>);
}

// Подготовка блока к майнеру (внешний проект web-block-miner). Готовый блок
// переводится в статус подготовки (preparing), а спустя MINING_PREPARATION_MS
// становится подготовленным (prepared) и доступным для передачи майнеру.
export async function prepareBlockForMining(
  number: number
): Promise<BlockRecord> {
  const block = await getBlockByNumber(number);
  if (!block) throw new Error("BLOCK_NOT_FOUND");
  if (block.status !== "ready") throw new Error("BLOCK_NOT_READY");
  if (block.miningStatus === "mined") throw new Error("ALREADY_MINED");
  if (block.miningStatus === "prepared") throw new Error("ALREADY_PREPARED");
  if (block.miningStatus === "preparing") throw new Error("ALREADY_PREPARING");

  const now = new Date().toISOString();
  const preparedAt = new Date(Date.now() + MINING_PREPARATION_MS).toISOString();

  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: BLOCK_PK, sk: padBlockNumber(number) },
      UpdateExpression: "SET prepareStartedAt = :now, preparedAt = :preparedAt",
      ExpressionAttributeValues: {
        ":now": now,
        ":preparedAt": preparedAt,
      },
    })
  );

  return (await getBlockByNumber(number)) as BlockRecord;
}

// Выпуск блока в сеть Ethereum: для блока без токена формируется уникальный
// токен-сертификат (номер, хеш содержимого, адрес контракта, хеш транзакции,
// ссылка на проводник) и сохраняется статус выпуска в сеть.
export async function issueBlockToken(number: number): Promise<BlockRecord> {
  const block = await getBlockByNumber(number);
  if (!block) throw new Error("BLOCK_NOT_FOUND");
  if (block.status !== "ready") throw new Error("BLOCK_NOT_READY");
  if (block.token) throw new Error("ALREADY_TOKENIZED");

  const token = buildTokenCertificate({
    number: block.number,
    sizeBytes: block.sizeBytes,
    fileName: block.fileName,
    content: block.content,
  });

  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: BLOCK_PK, sk: padBlockNumber(number) },
      UpdateExpression: "SET token = :token",
      ExpressionAttributeValues: { ":token": token },
    })
  );

  return (await getBlockByNumber(number)) as BlockRecord;
}

export async function listBlocks(limit = 50): Promise<BlockRecord[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk",
      ExpressionAttributeValues: { ":pk": BLOCK_PK },
      ScanIndexForward: false,
      Limit: limit,
    })
  );
  return (result.Items ?? []).map((item) =>
    toBlockRecord(item as Record<string, unknown>)
  );
}

export async function getBlocksOverview(): Promise<BlocksOverview> {
  const [stats, blocks] = await Promise.all([getBlockStats(), listBlocks(50)]);
  return { stats, blocks };
}

// Поиск блоков по истории (номер, дата, источник) и содержимому
// (сайты/новости/файлы из Интернет-архива внутри блока).
// Выполняется скан записей таблицы с фильтрацией по запросу; результаты
// сортируются по номеру блока по убыванию.
export async function searchBlocks(
  query: BlockSearchQuery,
  limit = 200
): Promise<BlockRecord[]> {
  const collected: BlockRecord[] = [];
  const maxScanned = 2000;
  let lastEvaluatedKey: Record<string, AttributeValue> | undefined;

  do {
    const result = await docClient.send(
      new ScanCommand({
        TableName: TableName.BLOCKS,
        FilterExpression: "pk = :pk",
        ExpressionAttributeValues: { ":pk": BLOCK_PK },
        Limit: 100,
        ExclusiveStartKey: lastEvaluatedKey,
      })
    );

    for (const item of result.Items ?? []) {
      collected.push(toBlockRecord(item as Record<string, unknown>));
    }

    lastEvaluatedKey = result.LastEvaluatedKey;
  } while (lastEvaluatedKey && collected.length < maxScanned);

  return collected
    .filter((block) => matchesBlockQuery(block, query))
    .sort((a, b) => b.number - a.number)
    .slice(0, limit);
}

function normalizeFactoryItem(item: Record<string, unknown>): FactoryState {
  const level = (item.level as number | undefined) ?? DEFAULT_FACTORY_LEVEL;
  return {
    level,
    blocksPerSecond: blocksPerSecondForLevel(level),
    coins: (item.coins as number | undefined) ?? 0,
    totalFactoryBlocks: (item.totalFactoryBlocks as number | undefined) ?? 0,
    upgradePrice: upgradePriceForLevel(level),
    maxLevel: MAX_FACTORY_LEVEL,
    startedAt: (item.startedAt as string | undefined) ?? "",
    updatedAt: (item.updatedAt as string | undefined) ?? "",
  };
}

async function seedFactoryState(): Promise<void> {
  const now = new Date().toISOString();
  try {
    await docClient.send(
      new PutCommand({
        TableName: TableName.BLOCKS,
        Item: {
          pk: FACTORY_PK,
          sk: FACTORY_SK,
          level: DEFAULT_FACTORY_LEVEL,
          coins: 0,
          totalFactoryBlocks: 0,
          startedAt: now,
          updatedAt: now,
        },
        ConditionExpression: "attribute_not_exists(pk)",
      })
    );
  } catch {
    void 0;
  }
}

async function creditCoins(amount: number): Promise<void> {
  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      UpdateExpression: "ADD #coins :amount",
      ExpressionAttributeNames: { "#coins": "coins" },
      ExpressionAttributeValues: { ":amount": amount },
    })
  );
}

export async function getFactoryState(): Promise<FactoryState> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
    })
  );

  if (!result.Item) {
    await seedFactoryState();
    const seeded = await docClient.send(
      new GetCommand({
        TableName: TableName.BLOCKS,
        Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      })
    );
    return normalizeFactoryItem((seeded.Item as Record<string, unknown>) ?? {});
  }

  return normalizeFactoryItem(result.Item as Record<string, unknown>);
}

export async function upgradeFactory(): Promise<FactoryState> {
  const state = await getFactoryState();

  if (state.level >= state.maxLevel) {
    throw new Error("MAX_LEVEL");
  }

  const price = state.upgradePrice;
  if (state.coins < price) {
    throw new Error("INSUFFICIENT_COINS");
  }

  const now = new Date().toISOString();
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      UpdateExpression:
        "SET #level = :level, updatedAt = :updatedAt ADD #coins :minusCoins",
      ExpressionAttributeNames: { "#level": "level", "#coins": "coins" },
      ExpressionAttributeValues: {
        ":level": state.level + 1,
        ":updatedAt": now,
        ":minusCoins": -price,
        ":price": price,
      },
      ConditionExpression: "#coins >= :price",
      ReturnValues: "ALL_NEW",
    })
  );

  return normalizeFactoryItem(result.Attributes as Record<string, unknown>);
}

export async function produceFactoryBlock(): Promise<BlockRecord> {
  const block = await createBlock("factory");
  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: FACTORY_PK, sk: FACTORY_SK },
      UpdateExpression: "ADD #total :one",
      ExpressionAttributeNames: { "#total": "totalFactoryBlocks" },
      ExpressionAttributeValues: { ":one": 1 },
    })
  );
  return block;
}

function normalizeMinerItem(item: Record<string, unknown>): MinerState {
  return {
    status: (item.status as MinerStatus | undefined) ?? "idle",
    currentBlockNumber:
      (item.currentBlockNumber as number | null | undefined) ?? null,
    processedBlocks: (item.processedBlocks as number | undefined) ?? 0,
    startedAt: (item.startedAt as string | null | undefined) ?? null,
    updatedAt: (item.updatedAt as string | undefined) ?? "",
  };
}

async function ensureMinerState(): Promise<void> {
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: MINER_PK, sk: MINER_SK },
    })
  );
  if (result.Item) return;
  try {
    await docClient.send(
      new PutCommand({
        TableName: TableName.BLOCKS,
        Item: {
          pk: MINER_PK,
          sk: MINER_SK,
          status: "idle",
          currentBlockNumber: null,
          processedBlocks: 0,
          startedAt: null,
          updatedAt: new Date().toISOString(),
        },
        ConditionExpression: "attribute_not_exists(pk)",
      })
    );
  } catch {
    void 0;
  }
}

export async function getMinerState(): Promise<MinerState> {
  await ensureMinerState();
  const result = await docClient.send(
    new GetCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: MINER_PK, sk: MINER_SK },
    })
  );
  return normalizeMinerItem((result.Item as Record<string, unknown>) ?? {});
}

export async function setMinerStatus(status: MinerStatus): Promise<MinerState> {
  await ensureMinerState();
  const now = new Date().toISOString();
  const result = await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: MINER_PK, sk: MINER_SK },
      UpdateExpression:
        "SET #status = :status, updatedAt = :now, startedAt = if_not_exists(startedAt, :now)",
      ExpressionAttributeNames: { "#status": "status" },
      ExpressionAttributeValues: { ":status": status, ":now": now },
      ReturnValues: "ALL_NEW",
    })
  );
  return normalizeMinerItem(result.Attributes as Record<string, unknown>);
}

export async function setMinerCurrentBlock(
  number: number | null
): Promise<void> {
  await ensureMinerState();
  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: MINER_PK, sk: MINER_SK },
      UpdateExpression: "SET currentBlockNumber = :number, updatedAt = :now",
      ExpressionAttributeValues: {
        ":number": number,
        ":now": new Date().toISOString(),
      },
    })
  );
}

async function incrementMinerProcessed(): Promise<void> {
  await ensureMinerState();
  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: MINER_PK, sk: MINER_SK },
      UpdateExpression: "ADD #processed :one SET updatedAt = :now",
      ExpressionAttributeNames: { "#processed": "processedBlocks" },
      ExpressionAttributeValues: {
        ":one": 1,
        ":now": new Date().toISOString(),
      },
    })
  );
}

// Запуск майнера: статус переводится в running, движок начинает обрабатывать
// подготовленные блоки (внешний проект web-block-miner).
export async function startMiner(): Promise<MinerState> {
  const state = await setMinerStatus("running");
  await appendMinerLog(
    "МАЙНЕР: ЗАПУЩЕН — ОБРАБОТКА ПОДГОТОВЛЕННЫХ БЛОКОВ",
    "ok"
  );
  return state;
}

export async function stopMiner(): Promise<MinerState> {
  await setMinerCurrentBlock(null);
  const state = await setMinerStatus("idle");
  await appendMinerLog("МАЙНЕР: ОСТАНОВЛЕН", "warn");
  return state;
}

// Подбор следующего блока для добычи: новейший подготовленный и ещё не
// добытый блок.
export async function listPreparedUnminedBlocks(
  maxScanned = 2000
): Promise<BlockRecord[]> {
  const collected: BlockRecord[] = [];
  let lastEvaluatedKey: Record<string, AttributeValue> | undefined;

  do {
    const result = await docClient.send(
      new ScanCommand({
        TableName: TableName.BLOCKS,
        FilterExpression: "pk = :pk",
        ExpressionAttributeValues: { ":pk": BLOCK_PK },
        Limit: 100,
        ExclusiveStartKey: lastEvaluatedKey,
      })
    );

    for (const item of result.Items ?? []) {
      const rec = toBlockRecord(item as Record<string, unknown>);
      if (rec.miningStatus === "prepared" && !rec.minedAt) {
        collected.push(rec);
      }
    }

    lastEvaluatedKey = result.LastEvaluatedKey;
  } while (lastEvaluatedKey && collected.length < maxScanned);

  return collected.sort((a, b) => b.number - a.number);
}

// Имитация proof-of-work внешнего майнера: подбор nonce, при котором
// sha256-хэш начинается с префикса сложности.
function mineHash(
  blockNumber: number,
  startedAt: string
): { hash: string; nonce: number } {
  let nonce = Math.floor(Math.random() * 1_000_000);
  const maxAttempts = 5_000_000;
  while (nonce < maxAttempts) {
    const hash = createHash("sha256")
      .update(`${blockNumber}:${nonce}:${startedAt}`)
      .digest("hex");
    if (hash.startsWith(MINING_DIFFICULTY)) return { hash, nonce };
    nonce++;
  }
  const hash = createHash("sha256")
    .update(`${blockNumber}:${nonce}:${startedAt}`)
    .digest("hex");
  return { hash, nonce };
}

export async function putMiningResult(result: MiningResult): Promise<void> {
  await docClient.send(
    new PutCommand({
      TableName: TableName.BLOCKS,
      Item: {
        pk: MINING_PK,
        sk: padBlockNumber(result.blockNumber),
        ...result,
      },
    })
  );
}

export async function getMiningResult(
  number: number
): Promise<MiningResult | null> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk AND sk = :sk",
      ExpressionAttributeValues: {
        ":pk": MINING_PK,
        ":sk": padBlockNumber(number),
      },
      Limit: 1,
    })
  );
  const item = result.Items?.[0];
  if (!item) return null;
  return {
    blockNumber: item.blockNumber as number,
    status: item.status as MiningResultStatus,
    startedAt: item.startedAt as string,
    completedAt: item.completedAt as string | undefined,
    hash: item.hash as string | undefined,
    nonce: item.nonce as number | undefined,
    difficulty: (item.difficulty as string | undefined) ?? MINING_DIFFICULTY,
    durationMs: item.durationMs as number | undefined,
  };
}

export async function getMiningResults(
  limit = MINING_RESULT_LIMIT
): Promise<MiningResult[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk",
      ExpressionAttributeValues: { ":pk": MINING_PK },
      ScanIndexForward: false,
      Limit: limit,
    })
  );
  return (result.Items ?? []).map((item) => ({
    blockNumber: item.blockNumber as number,
    status: item.status as MiningResultStatus,
    startedAt: item.startedAt as string,
    completedAt: item.completedAt as string | undefined,
    hash: item.hash as string | undefined,
    nonce: item.nonce as number | undefined,
    difficulty: (item.difficulty as string | undefined) ?? MINING_DIFFICULTY,
    durationMs: item.durationMs as number | undefined,
  }));
}

// Начало обработки блока майнером: создаётся результат со статусом
// processing и в лог пишется старт добычи.
export async function beginMining(number: number): Promise<MiningResult> {
  const result: MiningResult = {
    blockNumber: number,
    status: "processing",
    startedAt: new Date().toISOString(),
    difficulty: MINING_DIFFICULTY,
  };
  await putMiningResult(result);
  await appendMinerLog(
    `МАЙНЕР: НАЧАТА ДОБЫЧА БЛОКА #${String(number).padStart(9, "0")} (сложность ${MINING_DIFFICULTY}…)`,
    "info"
  );
  return result;
}

// Завершение добычи блока: вычисляется хэш/nonce, результат сохраняется,
// блок помечается добытым, счётчик обработанных увеличивается, в лог
// попадает итог добычи.
export async function completeMining(number: number): Promise<BlockRecord> {
  const block = await getBlockByNumber(number);
  if (!block) throw new Error("BLOCK_NOT_FOUND");

  const previous = await getMiningResult(number);
  const startedAt = previous?.startedAt ?? new Date().toISOString();
  const durationMs = Math.max(1, Date.now() - new Date(startedAt).getTime());
  const { hash, nonce } = mineHash(number, startedAt);
  const completedAt = new Date().toISOString();

  await putMiningResult({
    blockNumber: number,
    status: "done",
    startedAt,
    completedAt,
    hash,
    nonce,
    difficulty: MINING_DIFFICULTY,
    durationMs,
  });

  await docClient.send(
    new UpdateCommand({
      TableName: TableName.BLOCKS,
      Key: { pk: BLOCK_PK, sk: padBlockNumber(number) },
      UpdateExpression:
        "SET minedAt = :minedAt, minedHash = :hash, minedNonce = :nonce, minedDurationMs = :durationMs",
      ExpressionAttributeValues: {
        ":minedAt": completedAt,
        ":hash": hash,
        ":nonce": nonce,
        ":durationMs": durationMs,
      },
    })
  );

  await setMinerCurrentBlock(null);
  await incrementMinerProcessed();
  await appendMinerLog(
    `МАЙНЕР: БЛОК #${String(number).padStart(9, "0")} ДОБЫТ [${hash.slice(0, 8)}…] NONCE ${nonce} — OK`,
    "ok"
  );

  return (await getBlockByNumber(number)) as BlockRecord;
}

// Один шаг движка майнера: продолжить обработку текущего блока либо взять
// следующий подготовленный блок из очереди. Возвращает добытый блок, если
// на этом шаге добыча завершилась.
export async function mineNextBlock(): Promise<BlockRecord | null> {
  const state = await getMinerState();
  if (state.status !== "running") return null;

  // Продолжить блок, обработка которого уже начата.
  if (state.currentBlockNumber != null) {
    const current = await getBlockByNumber(state.currentBlockNumber);
    if (current && current.miningStatus === "prepared" && !current.minedAt) {
      const result = await getMiningResult(state.currentBlockNumber);
      if (result?.status === "processing") {
        const elapsed = Date.now() - new Date(result.startedAt).getTime();
        if (elapsed < MINING_DURATION_MS) return null;
        return completeMining(state.currentBlockNumber);
      }
    }
    await setMinerCurrentBlock(null);
  }

  // Взять следующий подготовленный блок.
  const candidates = await listPreparedUnminedBlocks();
  const target = candidates[0];
  if (!target) return null;

  await setMinerCurrentBlock(target.number);
  await beginMining(target.number);
  return null;
}

export async function appendMinerLog(
  text: string,
  tone: "info" | "ok" | "warn" = "info"
): Promise<void> {
  await docClient.send(
    new PutCommand({
      TableName: TableName.BLOCKS,
      Item: {
        pk: MINER_LOG_PK,
        sk: `${String(Date.now()).padStart(15, "0")}-${crypto.randomUUID().slice(0, 8)}`,
        time: new Date().toISOString(),
        text,
        tone,
      },
    })
  );
}

export async function getMinerLogs(
  limit = MINER_LOG_LIMIT
): Promise<MinerLogEntry[]> {
  const result = await docClient.send(
    new QueryCommand({
      TableName: TableName.BLOCKS,
      KeyConditionExpression: "pk = :pk",
      ExpressionAttributeValues: { ":pk": MINER_LOG_PK },
      ScanIndexForward: false,
      Limit: limit,
    })
  );
  return (result.Items ?? []).map((item) => ({
    id: item.sk as string,
    time: item.time as string,
    text: item.text as string,
    tone: (item.tone as "info" | "ok" | "warn") ?? "info",
  }));
}
